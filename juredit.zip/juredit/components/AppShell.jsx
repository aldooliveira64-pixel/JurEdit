"use client";
import { useState } from "react";
import JurHub from "./tools/JurHub";
import JurObra from "./tools/JurObra";
import JurPeca from "./tools/JurPeca";
import JurFinanceiro from "./tools/JurFinanceiro";
import JurBiblioteca from "./tools/JurBiblioteca";
import JurJurisprudencia from "./tools/JurJurisprudencia";

const TOOLS = [
  { id:"hub",    label:"JurHub",          icon:"🏠", desc:"Dashboard · bancos · export", component:JurHub,          cor:"#c49a2a" },
  { id:"obra",   label:"JurObra",         icon:"📚", desc:"Livros · tratados · teses",   component:JurObra,         cor:"#8b1a1a" },
  { id:"peca",   label:"JurPeça",         icon:"⚖️", desc:"Petição · parecer · contrato",component:JurPeca,         cor:"#7c3aed" },
  { id:"fin",    label:"JurFinanceiro",   icon:"📑", desc:"Bancário · Mercado de Capitais",component:JurFinanceiro, cor:"#0369a1" },
  { id:"bib",    label:"JurBiblioteca",   icon:"📖", desc:"Doutrina · 97 obras · ABNT",  component:JurBiblioteca,   cor:"#c49a2a" },
  { id:"jur",    label:"JurJurisprudência",icon:"🏛️",desc:"STF · STJ · súmulas · IA",   component:JurJurisprudencia,cor:"#0369a1" },
];

export default function AppShell() {
  const [active, setActive] = useState("hub");
  const [collapsed, setCollapsed] = useState(false);

  const tool = TOOLS.find(t => t.id === active);
  const ActiveComponent = tool?.component || JurHub;

  const C = { nav:"#12192e", gold:"#c49a2a", border:"#ddd9d0", textTer:"#999", bg:"#f5f4f1" };

  return (
    <div style={{ display:"flex", height:"100vh", overflow:"hidden", background:C.bg }}>

      {/* ── SIDEBAR ── */}
      <div style={{
        width: collapsed ? 56 : 210,
        background: C.nav,
        display: "flex",
        flexDirection: "column",
        flexShrink: 0,
        transition: "width .2s ease",
        overflow: "hidden",
        borderRight: "1px solid #0a1020",
      }}>
        {/* Logo */}
        <div style={{ padding: collapsed ? "14px 0" : "14px 16px", display:"flex", alignItems:"center", gap:10, borderBottom:"1px solid rgba(255,255,255,.08)", justifyContent: collapsed ? "center" : "flex-start" }}>
          {!collapsed && (
            <>
              <span style={{ color:C.gold, fontFamily:"monospace", fontWeight:700, fontSize:13, letterSpacing:".1em", whiteSpace:"nowrap" }}>JUREDIT</span>
              <span style={{ background:`${C.gold}25`, border:`1px solid ${C.gold}40`, color:C.gold, fontSize:8, padding:"1px 6px", borderRadius:2, fontFamily:"monospace", whiteSpace:"nowrap" }}>v2</span>
            </>
          )}
          <button onClick={() => setCollapsed(v => !v)}
            style={{ marginLeft:"auto", background:"none", border:"none", color:"rgba(255,255,255,.4)", cursor:"pointer", fontSize:16, padding:"0 4px", lineHeight:1, flexShrink:0 }}>
            {collapsed ? "›" : "‹"}
          </button>
        </div>

        {/* Navigation */}
        <nav style={{ flex:1, padding:"8px 6px", overflowY:"auto" }}>
          {TOOLS.map(t => {
            const isActive = active === t.id;
            return (
              <button key={t.id} onClick={() => setActive(t.id)}
                title={collapsed ? t.label : undefined}
                style={{
                  display:"flex", alignItems:"center", gap:10,
                  width:"100%", padding: collapsed ? "10px 0" : "9px 10px",
                  marginBottom:3, border:"none", borderRadius:6, cursor:"pointer",
                  textAlign:"left", justifyContent: collapsed ? "center" : "flex-start",
                  background: isActive ? `${t.cor}25` : "transparent",
                  borderLeft: isActive && !collapsed ? `3px solid ${t.cor}` : "3px solid transparent",
                  transition:"all .15s",
                }}>
                <span style={{ fontSize:16, flexShrink:0 }}>{t.icon}</span>
                {!collapsed && (
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:12, fontWeight:isActive?700:400, color:isActive?t.cor:"rgba(255,255,255,.65)", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{t.label}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,.3)", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", fontFamily:"monospace" }}>{t.desc}</div>
                  </div>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        {!collapsed && (
          <div style={{ padding:"10px 12px", borderTop:"1px solid rgba(255,255,255,.06)" }}>
            <div style={{ fontSize:9, color:"rgba(255,255,255,.2)", fontFamily:"monospace", lineHeight:1.6 }}>
              Next.js · Vercel · Anthropic<br/>
              © JurEdit 2025
            </div>
          </div>
        )}
      </div>

      {/* ── MAIN CONTENT ── */}
      <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
        <ActiveComponent />
      </div>
    </div>
  );
}
