"use client";
export default function RichText({ content }) {
  return (
    <div style={{ lineHeight: 1.75, fontSize: 13 }}>
      {(content || "").split("\n").map((line, i) => {
        if (!line.trim()) return <div key={i} style={{ height: 8 }} />;
        const parts = [];
        const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
        let last = 0, m;
        while ((m = re.exec(line)) !== null) {
          if (m.index > last) parts.push(<span key={last}>{line.slice(last, m.index)}</span>);
          const tok = m[0];
          if (tok.startsWith("**")) parts.push(<strong key={m.index}>{tok.slice(2,-2)}</strong>);
          else if (tok.startsWith("*")) parts.push(<em key={m.index}>{tok.slice(1,-1)}</em>);
          else parts.push(<code key={m.index} style={{background:"rgba(0,0,0,.07)",padding:"1px 5px",borderRadius:3,fontFamily:"monospace",fontSize:11}}>{tok.slice(1,-1)}</code>);
          last = m.index + tok.length;
        }
        if (last < line.length) parts.push(<span key={last}>{line.slice(last)}</span>);
        return <div key={i}>{parts}</div>;
      })}
    </div>
  );
}
