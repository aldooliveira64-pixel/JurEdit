"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import mammoth from "mammoth";
import RichText from "../shared/RichText";

const TIPOS_DOC={
  debenture:{label:"Escritura de Debêntures",icon:"📑",cor:"#0369a1",desc:"Escritura de emissão conforme Lei 6.404/76 e Resolução CVM vigente",acoes:[{ic:"📑",l:"Escritura completa",p:"Elabore escritura de emissão de debêntures completa conforme Lei 6.404/76 e Resolução CVM vigente, com espécie, conversibilidade, série, valor nominal, remuneração, vencimento, garantias, agente fiduciário, eventos de inadimplemento e assembleia de debenturistas. Emissão de: "},{ic:"📋",l:"Cláusula de remuneração",p:"Redija a cláusula de REMUNERAÇÃO com juros remuneratórios, periodicidade, base de cálculo, DU/360 e convenção de dias úteis para debêntures indexadas a: "},{ic:"⚠️",l:"Eventos de inadimplemento",p:"Redija cláusulas de EVENTOS DE INADIMPLEMENTO (vencimento antecipado automático e não automático) com cross-default, change of control e covenants financeiros para: "},{ic:"🏛️",l:"Assembleia de debenturistas",p:"Redija as cláusulas de CONVOCAÇÃO E DELIBERAÇÃO da Assembleia de Debenturistas, quórum de instalação e deliberação por tipo de matéria, para: "},{ic:"🔍",l:"Due diligence jurídica",p:"Realize due diligence jurídica da emissora para oferta de debêntures: condições de emissão, limitação estatutária, deliberação societária, registro CVM para: "}]},
  prospecto:{label:"Prospecto de Oferta",icon:"📊",cor:"#7c3aed",desc:"Prospecto preliminar ou definitivo de IPO/follow-on (Res. CVM 160/2022)",acoes:[{ic:"📊",l:"Fatores de risco",p:"Redija a seção de FATORES DE RISCO do prospecto conforme Resolução CVM 160/2022, cobrindo riscos macroeconômicos, setoriais, operacionais, regulatórios e societários, para companhia do setor: "},{ic:"🏢",l:"Visão geral da emissora",p:"Redija a seção SUMÁRIO DO EMISSOR: histórico, atividades, modelo de negócio, vantagens competitivas e estratégia, para: "},{ic:"💰",l:"Destinação dos recursos",p:"Redija a seção DESTINAÇÃO DOS RECURSOS com montante total, percentuais por destinação, cronograma de utilização e impacto na estrutura de capital, para oferta de R$ "},{ic:"📉",l:"Diluição",p:"Redija a seção DILUIÇÃO com posição acionária antes/após oferta, cálculo da diluição percentual e valor patrimonial por ação pré e pós-oferta, para: "}]},
  ccb:{label:"CCB",icon:"🏦",cor:"#065f46",desc:"Cédula de Crédito Bancário completa conforme Lei 10.931/2004",acoes:[{ic:"🏦",l:"CCB completa",p:"Elabore CCB completa conforme Lei 10.931/2004 com qualificação das partes, valor, taxa de juros remuneratórios, encargos moratórios, IOF, prazo, forma de pagamento, garantias e cláusula de execução extrajudicial, para operação de: "},{ic:"📋",l:"Cláusula de encargos",p:"Redija a cláusula de ENCARGOS FINANCEIROS da CCB com taxa de juros (nominal e efetiva anual), capitalização, encargos moratórios (multa + juros), correção monetária e IOF, para: "},{ic:"🛡️",l:"Garantias",p:"Redija as cláusulas de GARANTIAS da CCB com alienação fiduciária / cessão fiduciária / hipoteca, ou fiança/aval com renúncia aos benefícios de ordem e exoneração, para: "},{ic:"⚡",l:"Execução extrajudicial",p:"Redija a cláusula de EXECUÇÃO EXTRAJUDICIAL conforme arts. 37 e ss. da Lei 10.931/2004, com procedimento de consolidação da propriedade e leilão, para: "}]},
  cri_cra:{label:"CRI / CRA",icon:"🌿",cor:"#92400e",desc:"Termo de Securitização conforme Lei 9.514/97 (CRI) ou Lei 11.076/04 (CRA)",acoes:[{ic:"🌿",l:"Termo completo",p:"Elabore Termo de Securitização de CRI/CRA completo com créditos vinculados, regime fiduciário, emissora, agente fiduciário, remuneração, série, prazo e eventos de liquidação antecipada, para: "},{ic:"🔗",l:"Lastro e créditos",p:"Redija a seção de CRÉDITOS VINCULADOS com identificação, valor, cedente, cessão fiduciária ao patrimônio separado e razão de sobrecolateralização, para: "},{ic:"📊",l:"Análise de estrutura",p:"Faça análise crítica da estrutura de securitização proposta: riscos do lastro, concentração, subordinação, covenants e reforços de crédito (overcollateralization, fundo de reserva), para: "}]},
  pas_cvm:{label:"Defesa PAS CVM",icon:"⚖️",cor:"#991b1b",desc:"Defesa em Processo Administrativo Sancionador da CVM com teses estratégicas",acoes:[{ic:"⚖️",l:"Defesa completa",p:"Elabore defesa completa em PAS CVM com: I — DAS PRELIMINARES (nulidade, prescrição, decadência, cerceamento de defesa), II — DO MÉRITO (ausência de dolo ou culpa grave, nexo causal, ausência de dano ao mercado, boa-fé), III — DA SANÇÃO (proporcionalidade, precedentes favoráveis da CVM, atenuantes do art. 11 da Lei 6.385/76), para o caso: "},{ic:"🚫",l:"Preliminar de prescrição",p:"Elabore PRELIMINAR DE PRESCRIÇÃO em PAS CVM com prazo prescricional, dies a quo, causas interruptivas, jurisprudência do CRSFN e precedentes da CVM favoráveis, para acusação de: "},{ic:"💼",l:"Ausência de insider trading",p:"Elabore defesa de mérito por AUSÊNCIA DE INSIDER TRADING com inexistência de informação privilegiada, caráter público da informação, motivação legítima e ausência de elemento subjetivo, precedentes CVM/CRSFN, para: "},{ic:"📊",l:"Proporcionalidade da sanção",p:"Elabore tópico de PROPORCIONALIDADE DA SANÇÃO com critérios do art. 11, §2º da Lei 6.385/76 (natureza, gravidade, vantagem, situação econômica, reincidência, colaboração) e precedentes de penalidades similares da CVM, para: "}]},
  due_diligence:{label:"Due Diligence",icon:"🔍",cor:"#374151",desc:"Due diligence jurídico-regulatório para M&A, IPO ou operações estruturadas",acoes:[{ic:"🔍",l:"Due diligence completo",p:"Realize due diligence jurídico-regulatório completo: I — LICENÇAS E AUTORIZAÇÕES (CVM, BACEN, SUSEP, CADE), II — CONFORMIDADE (PLDFT, segurança cibernética, LGPD), III — CONTINGÊNCIAS REGULATÓRIAS (PAS CVM, autos de infração), IV — RISCOS DE COMPLIANCE, V — RECOMENDAÇÕES, para: "},{ic:"📋",l:"Checklist IPO",p:"Elabore checklist regulatório completo para IPO na B3/CVM: registro de companhia aberta (Res. CVM 80), registro de oferta (Res. CVM 160), segmento de listagem, requisitos de governança, free-float e estatutos, para: "},{ic:"⚠️",l:"Mapeamento de riscos",p:"Mapeie os riscos regulatórios com matriz de probabilidade × impacto: vedações regulatórias, aprovações prévias (BACEN, CVM, CADE, SUSEP), condições precedentes e mitigantes, para: "}]},
  consulta:{label:"Consulta ao Regulador",icon:"📮",cor:"#0369a1",desc:"Consulta formal à CVM, BACEN ou CMN com fundamentos e pedido de orientação",acoes:[{ic:"📮",l:"Consulta formal CVM",p:"Elabore consulta formal à CVM com identificação do consulente, descrição precisa da operação, questão jurídica submetida, fundamentos legais e regulatórios, entendimento do consulente, jurisprudência administrativa pertinente e pedido de orientação formal, sobre: "},{ic:"🏦",l:"Consulta formal BACEN",p:"Elabore consulta formal ao BACEN com apresentação da instituição, descrição da operação/produto pretendido, enquadramento normativo atual, pontos de incerteza regulatória e solicitação de manifestação sobre enquadramento/autorização, sobre: "},{ic:"📋",l:"Pedido de dispensa CVM",p:"Elabore pedido de dispensa de requisito à CVM com fundamentos (ausência de propósito protetivo, equivalência funcional, ônus desproporcional), precedentes de dispensas similares e comprometimentos assumidos, para: "}]},
};

const REGULADORES=["CVM","BACEN","CMN","SUSEP","CADE","IOSCO","B3","Todos"];
const NIVEIS=[{v:"Especialistas em Mercado de Capitais e Regulação Financeira",l:"Especialista MC"},{v:"Operadores do Direito — advogados e compliance officers",l:"Operadores do Direito"},{v:"Administradores e gestores de fundos",l:"Gestores"},{v:"Executivos sênior de instituições financeiras",l:"Alta Direção"}];
const NORMATIVAS=[
  {org:"Federal",tipo:"Lei",numero:"6.385/1976",tema:"CVM e Mercado de Valores Mobiliários",tags:["CVM","insider trading"]},
  {org:"Federal",tipo:"Lei",numero:"6.404/1976",tema:"Sociedades por Ações — Lei das S.A.",tags:["S.A.","debêntures"]},
  {org:"Federal",tipo:"Lei",numero:"9.514/1997",tema:"SFI — CRI e alienação fiduciária de imóvel",tags:["CRI","securitização"]},
  {org:"Federal",tipo:"Lei",numero:"10.931/2004",tema:"Cédula de Crédito Bancário — CCB",tags:["CCB","título executivo"]},
  {org:"Federal",tipo:"Lei",numero:"11.076/2004",tema:"CRA, CPR, CDCA e títulos do agronegócio",tags:["CRA","agronegócio"]},
  {org:"CVM",tipo:"Resolução",numero:"160/2022",tema:"Ofertas públicas de distribuição (ex-ICVM 400/476)",tags:["IPO","prospecto","oferta pública"]},
  {org:"CVM",tipo:"Resolução",numero:"80/2022",tema:"Companhias abertas — informações (ex-ICVM 480)",tags:["companhia aberta","DFP","ITR"]},
  {org:"CVM",tipo:"Resolução",numero:"17/2021",tema:"Fundos de Investimento",tags:["FI","FIA","cotistas"]},
  {org:"CVM",tipo:"Resolução",numero:"59/2021",tema:"Procedimento sancionador administrativo — PAS CVM",tags:["PAS","sanção","defesa"]},
  {org:"CMN",tipo:"Resolução",numero:"4.557/2017",tema:"Gerenciamento de riscos e capital (Basileia III)",tags:["risco","Basileia III"]},
  {org:"BACEN",tipo:"Circular",numero:"3.461/2009",tema:"PLDFT — prevenção à lavagem de dinheiro",tags:["PLDFT","KYC","compliance"]},
  {org:"CMN",tipo:"Resolução",numero:"4.656/2018",tema:"SCD e SEP — Fintechs de crédito",tags:["fintech","SCD","open banking"]},
  {org:"IOSCO",tipo:"Princípio",numero:"(38 princípios)",tema:"Principles for Securities Regulation",tags:["IOSCO","regulação internacional"]},
  {org:"BIS",tipo:"Acordo",numero:"Basileia III",tema:"Capital, alavancagem e liquidez para bancos",tags:["Basileia","capital","liquidez"]},
  {org:"EU",tipo:"Diretiva",numero:"MiFID II (2014/65/EU)",tema:"Mercados de Instrumentos Financeiros — proteção ao investidor",tags:["MiFID II","suitability","best execution"]},
];

function buildSystem(tipoKey,regulador,nivel){
  const tipo=TIPOS_DOC[tipoKey];
  return `Você é JurFinanceiro Excellence v1 — especialista em Direito Bancário e Mercado de Capitais com pesquisa web em tempo real.\n\nTipo de documento: ${tipo.label}\nRegulador primário: ${regulador} | Nível: ${nivel}\n\nBASE NORMATIVA VIGENTE EM 2025:\n• Lei 6.385/1976 (CVM) | Lei 6.404/1976 (S.A.) | Lei 10.931/2004 (CCB) | Lei 9.514/1997 (CRI) | Lei 11.076/2004 (CRA)\n• Resolução CVM 160/2022 (Ofertas — substitui ICVM 400/476)\n• Resolução CVM 80/2022 (Companhias abertas — substitui ICVM 480)\n• Basileia III | PLDFT (Circ. BACEN 3.461/2009)\n\nREGRAS ABSOLUTAS:\n✗ NUNCA cite instrução CVM revogada como vigente — use a Resolução CVM correspondente\n✗ NUNCA invente números de PAS CVM, processos ou julgados\n✓ Se não confirmado → "a CVM tem entendimento consolidado no sentido de..."\n✓ Para teses regulatórias: cite precedente CVM/CRSFN quando disponível\n✓ Termos estrangeiros em *itálico*: *insider trading*, *bookbuilding*, *covenant*, *waterfall*`;
}

export default function JurFinanceiro(){
  const[tipoKey,setTipoKey]=useState("debenture");
  const[regulador,setRegulador]=useState("CVM");
  const[nivel,setNivel]=useState(NIVEIS[0].v);
  const[titulo,setTitulo]=useState("");
  const[msgs,setMsgs]=useState([]);
  const[input,setInput]=useState("");
  const[loading,setLoading]=useState(false);
  const[exportStatus,setExportStatus]=useState("idle");
  const[sidebarOpen,setSidebarOpen]=useState(true);
  const[showNorm,setShowNorm]=useState(false);
  const[doc,setDoc]=useState(null);
  const[showUpload,setShowUpload]=useState(false);
  const[uploadErr,setUploadErr]=useState("");
  const fileInputRef=useRef(null);
  const bottomRef=useRef(null);
  const taRef=useRef(null);
  const tipo=TIPOS_DOC[tipoKey];

  useEffect(()=>{setMsgs([]);setDoc(null);},[tipoKey]);
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,loading]);
  useEffect(()=>{if(taRef.current){taRef.current.style.height="auto";taRef.current.style.height=Math.min(taRef.current.scrollHeight,160)+"px";}},[input]);

  const handleFile=async(file)=>{
    if(!file)return;
    if(file.size>30*1024*1024){setUploadErr("Arquivo muito grande (máx. 30MB).");return;}
    setUploadErr("");
    const ext=file.name.split(".").pop().toLowerCase();
    if(ext==="pdf"){const r=new FileReader();r.onload=e=>{setDoc({tipo:"pdf",base64:e.target.result.split(",")[1],nome:file.name});setShowUpload(false);};r.readAsDataURL(file);}
    else if(["docx","doc"].includes(ext)){const r=new FileReader();r.onload=async e=>{const x=await mammoth.extractRawText({arrayBuffer:e.target.result});setDoc({tipo:"docx",texto:x.value,nome:file.name});setShowUpload(false);};r.readAsArrayBuffer(file);}
    else setUploadErr("Use PDF ou DOCX.");
  };

  const enviar=useCallback(async(texto)=>{
    const prompt=texto||input.trim();
    if(!prompt&&!doc)return;
    if(loading)return;
    setInput("");
    let apiContent=prompt;
    if(doc){
      const instrucao=prompt||`Analise este documento conforme o tipo "${tipo.label}" e as normas regulatórias vigentes.`;
      if(doc.tipo==="pdf")apiContent=[{type:"document",source:{type:"base64",media_type:"application/pdf",data:doc.base64}},{type:"text",text:instrucao}];
      else apiContent=[{type:"text",text:`DOCUMENTO (${doc.nome}):\n\n${doc.texto.slice(0,30000)}\n\n---\n\n${instrucao}`}];
    }
    const novasMsgs=[...msgs,{role:"user",content:typeof apiContent==="string"?apiContent:prompt,docNome:doc?.nome,_api:apiContent}];
    setMsgs(novasMsgs);setLoading(true);
    try{
      const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:buildSystem(tipoKey,regulador,nivel),messages:novasMsgs.map(m=>({role:m.role,content:m._api||m.content})),tools:[{type:"web_search_20250305",name:"web_search"}]})});
      const data=await resp.json();
      const txt=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim();
      setMsgs(prev=>[...prev,{role:"assistant",content:txt||"Sem resposta."}]);setDoc(null);
    }catch(e){setMsgs(prev=>[...prev,{role:"assistant",content:"❌ Erro de conexão."}]);}
    finally{setLoading(false);}
  },[msgs,input,loading,tipoKey,regulador,nivel,doc]);

  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999",cor:tipo.cor};
  const hasContent=msgs.some(m=>m.role==="assistant");

  return(
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      <div style={{background:C.nav,padding:"0 18px",display:"flex",alignItems:"center",gap:10,height:48,flexShrink:0,borderBottom:"1px solid #0a1020"}}>
        <button onClick={()=>setSidebarOpen(v=>!v)} style={{background:"none",border:"none",color:"rgba(255,255,255,.5)",cursor:"pointer",fontSize:16}}>☰</button>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JURFINANCEIRO</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v1 · Fase 2</span>
        <span style={{fontSize:12,color:"rgba(255,255,255,.65)"}}>{tipo.icon} {tipo.label}</span>
        <div style={{marginLeft:"auto",display:"flex",gap:8}}>
          <button onClick={()=>setShowNorm(v=>!v)} style={{padding:"5px 12px",background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.6)",border:"1px solid rgba(255,255,255,.12)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>📚 Normativas ({NORMATIVAS.length})</button>
          {msgs.length>0&&<button onClick={()=>{if(window.confirm("Limpar?"))setMsgs([]);}} style={{padding:"5px 10px",background:"transparent",color:"rgba(255,255,255,.25)",border:"1px solid rgba(255,255,255,.08)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>limpar</button>}
        </div>
      </div>
      <div style={{flex:1,display:"flex",overflow:"hidden"}}>
        {sidebarOpen&&(
          <div style={{width:244,background:C.white,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
            <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:6}}>Tipo de documento</div>
              {Object.entries(TIPOS_DOC).map(([k,t])=>(
                <button key={k} onClick={()=>setTipoKey(k)} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:"6px 10px",marginBottom:3,border:"none",borderRadius:4,cursor:"pointer",textAlign:"left",background:tipoKey===k?`${t.cor}15`:"transparent",color:tipoKey===k?t.cor:C.textSec,fontWeight:tipoKey===k?700:400,borderLeft:tipoKey===k?`3px solid ${t.cor}`:"3px solid transparent",fontSize:12,fontFamily:"Georgia,serif",transition:"all .15s"}}>
                  <span>{t.icon}</span><span style={{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.label}</span>
                </button>
              ))}
            </div>
            <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Regulador</div>
              <select value={regulador} onChange={e=>setRegulador(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"monospace",fontSize:12,background:C.bg,outline:"none",marginBottom:8}}>
                {REGULADORES.map(r=><option key={r} value={r}>{r}</option>)}
              </select>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Nível</div>
              <select value={nivel} onChange={e=>setNivel(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:11,background:C.bg,outline:"none"}}>
                {NIVEIS.map(n=><option key={n.v} value={n.v}>{n.l}</option>)}
              </select>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"10px 14px"}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:6}}>Ações rápidas</div>
              {tipo.acoes.map((a,i)=>(
                <button key={i} onClick={()=>enviar(a.p)} style={{display:"flex",alignItems:"flex-start",gap:7,width:"100%",padding:"7px 9px",marginBottom:4,border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",textAlign:"left",background:"transparent",color:C.textSec,fontSize:11,fontFamily:"Georgia,serif",lineHeight:1.4,transition:"all .12s"}} onMouseOver={e=>{e.currentTarget.style.background=`${tipo.cor}10`;e.currentTarget.style.color=C.textPri;}} onMouseOut={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color=C.textSec;}}>
                  <span style={{flexShrink:0}}>{a.ic}</span><span>{a.l}</span>
                </button>
              ))}
            </div>
            <div style={{padding:"10px 14px",background:"#f7f3ec",borderTop:`1px solid ${C.border}`}}>
              <div style={{fontSize:10,color:C.textSec,lineHeight:1.5}}>{tipo.desc}</div>
            </div>
          </div>
        )}
        <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          {showNorm&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"10px 18px",flexShrink:0,maxHeight:220,overflowY:"auto"}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:12,fontWeight:500}}>📚 Base Normativa — {NORMATIVAS.length} normas</span><button onClick={()=>setShowNorm(false)} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:C.textTer}}>×</button></div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:6}}>
                {NORMATIVAS.map((n,i)=>(
                  <div key={i} style={{padding:"7px 10px",border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",background:"#faf8f4"}} onClick={()=>{setInput(p=>p?p+` Com base na ${n.tipo} ${n.numero}:`:`Com base na ${n.tipo} ${n.numero}, `);setShowNorm(false);}}>
                    <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:2}}><span style={{fontSize:9,fontFamily:"monospace",padding:"1px 6px",background:"#ede8df",borderRadius:8,color:C.textSec}}>{n.org}</span><span style={{fontSize:11,fontWeight:700,color:C.nav}}>{n.tipo} {n.numero}</span></div>
                    <div style={{fontSize:11,color:C.textSec,lineHeight:1.4}}>{n.tema}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {showUpload&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"14px 20px",flexShrink:0}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:12,fontWeight:500}}>Carregar documento regulatório (PDF/DOCX)</span><button onClick={()=>setShowUpload(false)} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:C.textTer}}>×</button></div>
              <div onDrop={e=>{e.preventDefault();handleFile(e.dataTransfer.files[0]);}} onDragOver={e=>e.preventDefault()} onClick={()=>fileInputRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:8,padding:"16px",textAlign:"center",cursor:"pointer",background:"#faf8f4"}}><div style={{fontSize:24,marginBottom:4}}>📄</div><div style={{fontSize:12,color:C.textSec}}>Arraste PDF ou DOCX · ou clique · máx. 30MB</div><div style={{fontSize:11,color:C.textTer,marginTop:2}}>Contrato bancário · PAS CVM · Prospecto · Escritura · Norma regulatória</div></div>
              <input ref={fileInputRef} type="file" accept=".pdf,.docx,.doc" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])}/>
              {uploadErr&&<div style={{marginTop:6,fontSize:11,color:"#991b1b",fontFamily:"monospace"}}>❌ {uploadErr}</div>}
            </div>
          )}
          {!showUpload&&doc&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"7px 18px",flexShrink:0}}>
              <span style={{display:"inline-flex",alignItems:"center",gap:6,padding:"3px 10px",background:`${tipo.cor}12`,border:`1px solid ${tipo.cor}30`,borderRadius:12,fontSize:11,fontFamily:"monospace",color:tipo.cor}}>
                {doc.tipo==="pdf"?"📕":"📝"} {doc.nome.slice(0,30)}<button onClick={()=>setDoc(null)} style={{background:"none",border:"none",cursor:"pointer",color:"inherit",fontSize:12,padding:"0 0 0 4px"}}>×</button>
              </span>
            </div>
          )}
          <div style={{flex:1,overflowY:"auto",padding:"20px 24px"}}>
            {msgs.length===0&&(
              <div style={{maxWidth:560,margin:"36px auto 0",textAlign:"center"}}>
                <div style={{fontSize:36,marginBottom:10}}>{tipo.icon}</div>
                <div style={{fontSize:18,fontWeight:700,marginBottom:6}}>JurFinanceiro v1</div>
                <div style={{fontSize:13,color:C.textSec,lineHeight:1.7,marginBottom:6}}>{tipo.label}</div>
                <div style={{fontSize:11,color:C.textTer,fontFamily:"monospace",marginBottom:16}}>{tipo.desc}</div>
                <div style={{marginBottom:14,padding:"10px 14px",background:"#eff6ff",border:"1px solid #bfdbfe",borderRadius:6,fontSize:11,color:"#1e40af",textAlign:"left"}}>💡 Use 📎 para carregar um contrato bancário, escritura, prospecto ou PAS CVM — a IA analisa com base nas normas regulatórias vigentes.</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,textAlign:"left"}}>
                  {tipo.acoes.slice(0,4).map((a,i)=><button key={i} onClick={()=>enviar(a.p)} style={{padding:"10px 12px",border:`1px solid ${C.border}`,borderRadius:6,cursor:"pointer",background:C.white,textAlign:"left",fontSize:12,color:C.textSec,fontFamily:"Georgia,serif",lineHeight:1.4}} onMouseOver={e=>{e.currentTarget.style.borderColor=tipo.cor;}} onMouseOut={e=>{e.currentTarget.style.borderColor=C.border;}}>{a.ic} {a.l}</button>)}
                </div>
              </div>
            )}
            {msgs.map((m,i)=>(
              <div key={i} style={{marginBottom:20,display:"flex",gap:12,justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                {m.role==="assistant"&&<div style={{width:28,height:28,background:tipo.cor,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0,marginTop:2}}>{tipo.icon}</div>}
                <div style={{maxWidth:"82%"}}>
                  {m.docNome&&<div style={{display:"flex",marginBottom:4,justifyContent:"flex-end"}}><span style={{fontSize:10,fontFamily:"monospace",padding:"2px 8px",background:`${tipo.cor}15`,border:`1px solid ${tipo.cor}30`,borderRadius:10,color:tipo.cor}}>📄 {m.docNome?.slice(0,22)}</span></div>}
                  <div style={{padding:"12px 16px",borderRadius:m.role==="user"?"16px 4px 16px 16px":"4px 16px 16px 16px",background:m.role==="user"?C.nav:C.white,color:m.role==="user"?"white":C.textPri,border:m.role==="assistant"?`1px solid ${C.border}`:"none",fontSize:13,lineHeight:1.75}}>
                    {m.role==="assistant"?<RichText content={m.content}/>:<span style={{fontFamily:"Georgia,serif",fontSize:13}}>{typeof m.content==="string"?m.content:"[documento enviado]"}</span>}
                  </div>
                </div>
              </div>
            ))}
            {loading&&<div style={{display:"flex",gap:12,marginBottom:20}}><div style={{width:28,height:28,background:tipo.cor,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>{tipo.icon}</div><div style={{padding:"12px 16px",background:C.white,border:`1px solid ${C.border}`,borderRadius:"4px 16px 16px 16px",display:"flex",gap:6,alignItems:"center"}}>{[0,1,2].map(j=><div key={j} style={{width:7,height:7,borderRadius:"50%",background:tipo.cor,opacity:.5,animation:`bounce 1.2s ease-in-out ${j*.2}s infinite`}}/>)}</div></div>}
            <div ref={bottomRef}/>
          </div>
          <div style={{borderTop:`1px solid ${C.border}`,background:C.white,padding:"12px 18px"}}>
            <div style={{display:"flex",gap:8,alignItems:"flex-end",maxWidth:900,margin:"0 auto"}}>
              <button onClick={()=>setShowUpload(v=>!v)} title="Carregar PDF ou DOCX regulatório" style={{width:40,height:40,display:"flex",alignItems:"center",justifyContent:"center",border:`1px solid ${doc?tipo.cor:C.border}`,borderRadius:8,cursor:"pointer",background:doc?`${tipo.cor}12`:C.bg,color:doc?tipo.cor:C.textTer,fontSize:18,flexShrink:0}}>📎</button>
              <textarea ref={taRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();enviar();}}} placeholder={doc?"Instrução adicional para análise...":"Descreva a operação ou questão regulatória... (Enter para enviar)"} rows={1} style={{flex:1,padding:"10px 14px",border:`1px solid ${C.border}`,borderRadius:8,fontFamily:"Georgia,serif",fontSize:13,resize:"none",outline:"none",lineHeight:1.6,overflow:"hidden",background:C.bg,color:C.textPri}} onFocus={e=>e.target.style.borderColor=tipo.cor} onBlur={e=>e.target.style.borderColor=C.border}/>
              <button onClick={()=>enviar()} disabled={loading||(!input.trim()&&!doc)} style={{padding:"10px 18px",background:loading||(!input.trim()&&!doc)?"#ccc":tipo.cor,color:"white",border:"none",borderRadius:8,cursor:loading||(!input.trim()&&!doc)?"not-allowed":"pointer",fontSize:16,flexShrink:0,height:40}}>↑</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
