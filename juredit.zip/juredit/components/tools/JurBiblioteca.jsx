"use client";
import { useState, useCallback } from "react";

const K_BIB="jura-bib-cache";
async function bibCacheAdd(texto){try{const r=await window.storage?.get(K_BIB);const a=r?.value?JSON.parse(r.value):[];if(!Array.isArray(a)||a.some(x=>x.texto===texto))return;await window.storage?.set(K_BIB,JSON.stringify([...a,{id:Date.now(),texto,ts:new Date().toLocaleDateString("pt-BR")}]));}catch{}}
async function bibCacheAddLocal(texto){try{const raw=localStorage.getItem(K_BIB);const a=raw?JSON.parse(raw):[];if(!Array.isArray(a)||a.some(x=>x.texto===texto))return;localStorage.setItem(K_BIB,JSON.stringify([...a,{id:Date.now(),texto,ts:new Date().toLocaleDateString("pt-BR")}]));}catch{}}

const CLASSICOS=[
  {id:"cgd",area:"Processo Civil",autores:"CINTRA, Antônio Carlos de Araújo; GRINOVER, Ada Pellegrini; DINAMARCO, Cândido Rangel",titulo:"Teoria Geral do Processo",edicao:"32",cidade:"São Paulo",editora:"Malheiros",ano:"2020",tipo:"Livro",tags:["teoria geral","jurisdição","ação","defesa"]},
  {id:"did1",area:"Processo Civil",autores:"DIDIER JR., Fredie",titulo:"Curso de Direito Processual Civil",volume:"I",edicao:"25",cidade:"Salvador",editora:"JusPodivm",ano:"2024",tipo:"Livro",tags:["normas fundamentais","pressupostos","competência"]},
  {id:"mar1",area:"Processo Civil",autores:"MARINONI, Luiz Guilherme; ARENHART, Sérgio Cruz; MITIDIERO, Daniel",titulo:"Curso de Processo Civil",volume:"I",edicao:"11",cidade:"São Paulo",editora:"Thomson Reuters Brasil",ano:"2023",tipo:"Livro",tags:["teoria geral","tutela","CPC"]},
  {id:"tar1",area:"Direito Civil",autores:"TARTUCE, Flávio",titulo:"Direito Civil",volume:"I",edicao:"20",cidade:"Rio de Janeiro",editora:"Forense",ano:"2024",tipo:"Livro",tags:["LINDB","pessoas","bens","negócio jurídico"]},
  {id:"caio",area:"Direito Civil",autores:"PEREIRA, Caio Mário da Silva",titulo:"Instituições de Direito Civil",volume:"I",edicao:"33",cidade:"Rio de Janeiro",editora:"Forense",ano:"2024",tipo:"Livro",tags:["pessoas","bens","fatos jurídicos"]},
  {id:"ps",area:"Direito Civil",autores:"GAGLIANO, Pablo Stolze; PAMPLONA FILHO, Rodolfo",titulo:"Manual de Direito Civil",edicao:"8",cidade:"São Paulo",editora:"Saraiva",ano:"2024",tipo:"Livro",tags:["contratos","família","sucessões"]},
  {id:"jas",area:"Direito Constitucional",autores:"SILVA, José Afonso da",titulo:"Curso de Direito Constitucional Positivo",edicao:"44",cidade:"São Paulo",editora:"Malheiros",ano:"2024",tipo:"Livro",tags:["constituição","direitos fundamentais","organização"]},
  {id:"gmc",area:"Direito Constitucional",autores:"MENDES, Gilmar Ferreira; BRANCO, Paulo Gustavo Gonet",titulo:"Curso de Direito Constitucional",edicao:"19",cidade:"São Paulo",editora:"Saraiva",ano:"2024",tipo:"Livro",tags:["direitos fundamentais","controle de constitucionalidade"]},
  {id:"bar",area:"Direito Constitucional",autores:"BARROSO, Luís Roberto",titulo:"Curso de Direito Constitucional Contemporâneo",edicao:"10",cidade:"São Paulo",editora:"Saraiva",ano:"2023",tipo:"Livro",tags:["neoconstitucionalismo","direitos fundamentais","interpretação"]},
  {id:"alex",area:"Direito Constitucional",autores:"ALEXY, Robert",titulo:"Teoria dos Direitos Fundamentais",edicao:"2",cidade:"São Paulo",editora:"Malheiros",ano:"2017",tipo:"Livro",tags:["princípios","regras","ponderação","proporcionalidade"]},
  {id:"grg",area:"Direito Penal",autores:"GRECO, Rogério",titulo:"Curso de Direito Penal: Parte Geral",volume:"I",edicao:"25",cidade:"Niterói",editora:"Impetus",ano:"2023",tipo:"Livro",tags:["crime","tipicidade","culpabilidade","pena"]},
  {id:"bito",area:"Direito Penal",autores:"BITENCOURT, Cezar Roberto",titulo:"Tratado de Direito Penal: Parte Geral",volume:"I",edicao:"28",cidade:"São Paulo",editora:"Saraiva",ano:"2022",tipo:"Livro",tags:["tratado","parte geral","teoria do crime"]},
  {id:"hel",area:"Direito Administrativo",autores:"MEIRELLES, Hely Lopes",titulo:"Direito Administrativo Brasileiro",edicao:"44",cidade:"São Paulo",editora:"Malheiros",ano:"2023",tipo:"Livro",tags:["ato administrativo","licitação","serviço público"]},
  {id:"dip",area:"Direito Administrativo",autores:"DI PIETRO, Maria Sylvia Zanella",titulo:"Direito Administrativo",edicao:"37",cidade:"Rio de Janeiro",editora:"Forense",ano:"2024",tipo:"Livro",tags:["ato administrativo","processo administrativo","contratos"]},
  {id:"ban",area:"Direito Administrativo",autores:"BANDEIRA DE MELLO, Celso Antônio",titulo:"Curso de Direito Administrativo",edicao:"35",cidade:"São Paulo",editora:"Malheiros",ano:"2022",tipo:"Livro",tags:["princípios","ato administrativo","responsabilidade"]},
  {id:"pbc",area:"Direito Tributário",autores:"CARVALHO, Paulo de Barros",titulo:"Curso de Direito Tributário",edicao:"32",cidade:"São Paulo",editora:"Saraiva",ano:"2021",tipo:"Livro",tags:["regra-matriz","lançamento","obrigação tributária"]},
  {id:"hugo",area:"Direito Tributário",autores:"MACHADO, Hugo de Brito",titulo:"Curso de Direito Tributário",edicao:"44",cidade:"São Paulo",editora:"Malheiros",ano:"2023",tipo:"Livro",tags:["CTN","crédito tributário","lançamento"]},
  {id:"god",area:"Direito do Trabalho",autores:"DELGADO, Maurício Godinho",titulo:"Curso de Direito do Trabalho",edicao:"23",cidade:"São Paulo",editora:"LTr",ano:"2024",tipo:"Livro",tags:["contrato de trabalho","princípios","CLT"]},
  {id:"spm",area:"Direito do Trabalho",autores:"MARTINS, Sérgio Pinto",titulo:"Direito do Trabalho",edicao:"40",cidade:"São Paulo",editora:"Saraiva",ano:"2024",tipo:"Livro",tags:["CLT","contrato","jornada","salário"]},
  {id:"fuc1",area:"Direito Empresarial",autores:"COELHO, Fábio Ulhoa",titulo:"Curso de Direito Comercial",volume:"I",edicao:"25",cidade:"São Paulo",editora:"Thomson Reuters Brasil",ano:"2023",tipo:"Livro",tags:["empresa","empresário","sociedades"]},
  {id:"ben",area:"Direito do Consumidor",autores:"BENJAMIN, Antônio Herman V.; MARQUES, Claudia Lima; BESSA, Leonardo Roscoe",titulo:"Manual de Direito do Consumidor",edicao:"11",cidade:"São Paulo",editora:"Thomson Reuters Brasil",ano:"2022",tipo:"Livro",tags:["CDC","responsabilidade","práticas abusivas"]},
  {id:"kel",area:"Teoria do Direito",autores:"KELSEN, Hans",titulo:"Teoria Pura do Direito",edicao:"8",cidade:"São Paulo",editora:"Martins Fontes",ano:"2009",tipo:"Livro",tags:["norma","validade","positivismo","clássico"]},
  {id:"dw",area:"Teoria do Direito",autores:"DWORKIN, Ronald",titulo:"Levando os Direitos a Sério",edicao:"3",cidade:"São Paulo",editora:"Martins Fontes",ano:"2010",tipo:"Livro",tags:["direitos","princípios","integridade","clássico"]},
  {id:"abr",area:"Direito Bancário",autores:"ABRÃO, Nelson",titulo:"Curso de Direito Bancário",edicao:"17",cidade:"São Paulo",editora:"Atlas",ano:"2022",tipo:"Livro",tags:["contrato bancário","crédito","operações ativas"]},
  {id:"sal",area:"Direito Bancário",autores:"SALOMÃO NETO, Eduardo",titulo:"Direito Bancário",edicao:"3",cidade:"São Paulo",editora:"Atlas",ano:"2014",tipo:"Livro",tags:["sistema financeiro","contratos bancários","depósito"]},
  {id:"eiz1",area:"Mercado de Capitais",autores:"EIZIRIK, Nelson; GAAL, Ariádna B.; PARENTE, Flávia; HENRIQUES, Marcus de Freitas",titulo:"Mercado de Capitais: Regime Jurídico",edicao:"4",cidade:"São Paulo",editora:"Quartier Latin",ano:"2019",tipo:"Livro",tags:["CVM","valores mobiliários","ofertas públicas","insider trading"]},
  {id:"yaz",area:"Mercado de Capitais",autores:"YAZBEK, Otavio",titulo:"Regulação do Mercado Financeiro e de Capitais",edicao:"2",cidade:"Rio de Janeiro",editora:"Elsevier",ano:"2009",tipo:"Livro",tags:["regulação","CVM","BACEN","sistema financeiro"]},
  {id:"ibs",area:"Direito Previdenciário",autores:"IBRAHIM, Fábio Zambitte",titulo:"Curso de Direito Previdenciário",edicao:"27",cidade:"Niterói",editora:"Impetus",ano:"2022",tipo:"Livro",tags:["previdência","custeio","benefícios","RGPS"]},
];

const AREAS_FILTRO=["Todas as áreas","Processo Civil","Direito Civil","Direito Constitucional","Direito Penal","Direito Administrativo","Direito Tributário","Direito do Trabalho","Direito Empresarial","Direito do Consumidor","Teoria do Direito","Direito Bancário","Mercado de Capitais","Direito Previdenciário"];
const PERIODOS=["Qualquer período","2020–2025","2015–2019","2010–2014","Clássicos (até 2009)"];

function abntCompleta(r){const vol=r.volume?`, v. ${r.volume}`:"";const ed=r.edicao?`. ${r.edicao}. ed.`:"";return `${r.autores}. **${r.titulo}**${vol}${ed} ${r.cidade}: ${r.editora}, ${r.ano}.`;}
function notaFormatada(r){const sobrenome=r.autores.split(";")[0].trim().split(",")[0].trim();const vol=r.volume?`, v. ${r.volume}`:"";const ed=r.edicao?`, ${r.edicao}. ed.`:"";return `N ${sobrenome}, *${r.titulo}*${vol}${ed}, ${r.cidade}, ${r.editora}, ${r.ano}.`;}

function RefCard({r}){
  const[cp,setCp]=useState(null);const[saved,setSaved]=useState(null);
  const C={border:"#ddd9d0",bg:"#faf8f4",nav:"#12192e",gold:"#c49a2a",textSec:"#555",textTer:"#999"};
  const copiar=async(texto,key)=>{navigator.clipboard?.writeText(texto);await bibCacheAddLocal(texto);setCp(key);setSaved(key);setTimeout(()=>{setCp(null);setSaved(null);},2500);};
  return(
    <div style={{background:"white",border:`1px solid ${C.border}`,borderRadius:6,padding:"14px 16px",marginBottom:10}}>
      <div style={{display:"flex",gap:8,marginBottom:8,flexWrap:"wrap",alignItems:"center"}}>
        <span style={{background:`${C.gold}20`,color:C.gold,border:`1px solid ${C.gold}40`,fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace"}}>{r.area}</span>
        <span style={{background:"#ede8df",color:C.textSec,fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace"}}>{r.tipo} · {r.ano}</span>
        {saved&&<span style={{background:"#f0fdf4",color:"#166534",border:"1px solid #86efac",fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace",marginLeft:"auto"}}>✅ salvo no Hub</span>}
      </div>
      <div style={{fontSize:14,fontWeight:700,color:C.nav,marginBottom:3}}>{r.titulo}{r.volume&&<span style={{fontWeight:400,color:C.textSec}}>, v. {r.volume}</span>}</div>
      <div style={{fontSize:12,color:C.textSec,marginBottom:10,lineHeight:1.5}}>{r.autores}</div>
      <div style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:4,padding:"8px 12px",fontSize:11,fontFamily:"monospace",lineHeight:1.7,marginBottom:10}}>
        <span style={{fontSize:9,color:C.textTer,display:"block",marginBottom:2,textTransform:"uppercase"}}>ABNT · Nota de rodapé</span>
        <sup>N</sup> {r.autores.split(";")[0].trim().split(",")[0].trim()}, <em>{r.titulo}</em>{r.volume?`, v. ${r.volume}`:""}{r.edicao?`, ${r.edicao}. ed.`:""}, {r.cidade}, {r.editora}, {r.ano}.
      </div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
        <button onClick={()=>copiar(abntCompleta(r),"abnt")} style={{padding:"5px 13px",background:cp==="abnt"?"#f0fdf4":"transparent",border:`1px solid ${cp==="abnt"?"#86efac":"#ddd9d0"}`,borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:cp==="abnt"?"#166534":"#555",transition:"all .15s"}}>{cp==="abnt"?"✅ copiado + salvo!":"📋 Copiar ABNT"}</button>
        <button onClick={()=>copiar(notaFormatada(r),"fn")} style={{padding:"5px 13px",background:cp==="fn"?"#f0fdf4":"transparent",border:`1px solid ${cp==="fn"?"#86efac":"#ddd9d0"}`,borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:cp==="fn"?"#166534":"#555",transition:"all .15s"}}>{cp==="fn"?"✅ copiado + salvo!":"ⁿ Copiar nota"}</button>
        {r.tags&&<div style={{display:"flex",gap:4,flexWrap:"wrap",marginLeft:"auto"}}>{r.tags.slice(0,4).map(t=><span key={t} style={{fontSize:9,padding:"2px 7px",background:"#ede8df",borderRadius:10,color:"#999",fontFamily:"monospace"}}>{t}</span>)}</div>}
      </div>
    </div>
  );
}

export default function JurBiblioteca(){
  const[busca,setBusca]=useState("");const[area,setArea]=useState("Todas as áreas");const[periodo,setPeriodo]=useState("Qualquer período");const[modo,setModo]=useState("classicos");const[loading,setLoading]=useState(false);const[iaResult,setIaResult]=useState("");const[iaErro,setIaErro]=useState("");const[cpTodos,setCpTodos]=useState(false);

  const resultados=CLASSICOS.filter(r=>{const q=busca.toLowerCase();const mB=!busca||[r.titulo,r.autores,...(r.tags||[])].some(s=>s.toLowerCase().includes(q));const mA=area==="Todas as áreas"||r.area===area;const mP=periodo==="Qualquer período"||(()=>{const a=parseInt(r.ano);if(periodo==="2020–2025")return a>=2020;if(periodo==="2015–2019")return a>=2015&&a<=2019;if(periodo==="2010–2014")return a>=2010&&a<=2014;if(periodo==="Clássicos (até 2009)")return a<=2009;return true;})();return mB&&mA&&mP;});

  const buscarIA=useCallback(async()=>{
    if(!busca.trim())return;
    setLoading(true);setIaResult("");setIaErro("");
    try{
      const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:`Pesquise e liste referências doutrinárias REAIS sobre:\nTema: "${busca}"${area!=="Todas as áreas"?`\nÁrea: ${area}`:""}${periodo!=="Qualquer período"?`\nPeríodo: ${periodo}`:""}\n\nREGRAS: Somente obras que você tem certeza que existem. Se não tiver certeza da edição/página, omita.\nIncluir obras nacionais E estrangeiras. Priorize 2018–2025 (exceto clássicos indispensáveis).\n\nPara cada obra:\n**[SOBRENOME, Prenome. *Título*. N. ed. Cidade: Editora, Ano.]**\nNota de rodapé: [SOBRENOME, *Título abrev.*, ed., cidade, editora, ano, p. XX.]\n\nAo final: "**COMO USAR NO TEXTO:**" com 3 exemplos de citação integrada.\nListe pelo menos 8 obras:`}],tools:[{type:"web_search_20250305",name:"web_search"}]})});
      const data=await resp.json();const txt=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim();
      if(!txt)throw new Error("Resposta vazia.");setIaResult(txt);
    }catch(e){setIaErro("❌ Erro: "+(e.message||"verifique a conexão."));}
    setLoading(false);
  },[busca,area,periodo]);

  const copiarTodos=async()=>{const txt=resultados.map(r=>abntCompleta(r)).join("\n");navigator.clipboard?.writeText(txt);await bibCacheAddLocal(txt);setCpTodos(true);setTimeout(()=>setCpTodos(false),3000);};

  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999"};

  return(
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      <div style={{background:C.nav,padding:"0 22px",display:"flex",alignItems:"center",gap:12,height:48,flexShrink:0,borderBottom:"1px solid #0a1020"}}>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JURBIBLIOTECA</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v2 · {CLASSICOS.length} obras · auto-save Hub</span>
        <span style={{fontSize:11,color:"rgba(255,255,255,.4)",fontFamily:"monospace"}}>Copiar → grava automaticamente no Hub</span>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"18px 20px",maxWidth:900,margin:"0 auto",width:"100%",boxSizing:"border-box"}}>
        <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,padding:"14px 18px",marginBottom:14}}>
          <div style={{display:"flex",gap:10,marginBottom:10}}>
            <input value={busca} onChange={e=>setBusca(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&modo==="ia")buscarIA();}} placeholder="Buscar por tema, autor ou título..." style={{flex:1,padding:"9px 12px",border:`1px solid ${C.border}`,borderRadius:6,fontFamily:"Georgia,serif",fontSize:13,color:C.textPri,background:C.bg,outline:"none"}}/>
            {modo==="ia"&&<button onClick={buscarIA} disabled={loading||!busca.trim()} style={{padding:"9px 20px",background:loading?"#aaa":C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:13,fontFamily:"monospace",fontWeight:700,whiteSpace:"nowrap"}}>{loading?"⏳...":"🔍 Buscar IA"}</button>}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
            {[["Área",area,setArea,AREAS_FILTRO],["Período",periodo,setPeriodo,PERIODOS]].map(([label,val,setter,opts])=>(
              <div key={label}><div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>{label}</div><select value={val} onChange={e=>setter(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:12,background:C.bg,outline:"none"}}>{opts.map(o=><option key={o} value={o}>{o}</option>)}</select></div>
            ))}
          </div>
        </div>
        <div style={{display:"flex",gap:0,marginBottom:14,borderBottom:`1px solid ${C.border}`}}>
          {[["classicos",`📚 Clássicos (${CLASSICOS.length})`],["ia","🔍 Busca IA + Web"]].map(([id,label])=>(
            <button key={id} onClick={()=>setModo(id)} style={{padding:"9px 20px",fontSize:12,fontFamily:"monospace",border:"none",background:modo===id?C.white:"transparent",cursor:"pointer",color:modo===id?C.nav:C.textTer,fontWeight:modo===id?700:400,borderBottom:modo===id?`2px solid ${C.gold}`:"2px solid transparent",marginBottom:-1}}>{label}</button>
          ))}
        </div>
        {modo==="classicos"&&(
          <>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}><span style={{fontSize:11,fontFamily:"monospace",color:C.textTer}}>{resultados.length} resultado{resultados.length!==1?"s":""}</span>{resultados.length>0&&<button onClick={copiarTodos} style={{padding:"5px 14px",background:cpTodos?"#f0fdf4":"transparent",border:`1px solid ${cpTodos?"#86efac":C.border}`,borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:cpTodos?"#166534":C.textSec}}>{cpTodos?"✅ copiado + salvo!":"📋 Copiar todos ABNT"}</button>}</div>
            {resultados.length===0?<div style={{textAlign:"center",padding:"40px 0",color:C.textTer}}><div style={{fontSize:32,marginBottom:10}}>📚</div><div style={{fontSize:13}}>Nenhuma obra encontrada</div><button onClick={()=>setModo("ia")} style={{marginTop:12,padding:"8px 20px",background:C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:12,fontFamily:"monospace"}}>🔍 Busca IA</button></div>:resultados.map((r,i)=><RefCard key={r.id||i} r={r}/>)}
          </>
        )}
        {modo==="ia"&&(
          <>
            {iaErro&&<div style={{padding:"10px 14px",background:"#fef2f2",border:"1px solid #fca5a5",borderRadius:4,fontSize:12,color:"#991b1b",fontFamily:"monospace",marginBottom:12}}>{iaErro}</div>}
            {!iaResult&&!loading&&!iaErro&&<div style={{textAlign:"center",padding:"48px 0",color:C.textTer}}><div style={{fontSize:36,marginBottom:14}}>📚</div><div style={{fontSize:13,color:C.textSec}}>Digite o tema e clique em Buscar IA</div></div>}
            {loading&&<div style={{textAlign:"center",padding:"48px 0"}}><div style={{fontSize:13,color:C.textSec,fontFamily:"monospace",marginBottom:16}}>⏳ Pesquisando doutrina + web...</div></div>}
            {iaResult&&(
              <div style={{background:"white",border:"1px solid #ddd9d0",borderLeft:"3px solid #16a34a",borderRadius:6,padding:"16px",marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}><span style={{fontSize:10,fontFamily:"monospace",color:"#166534",fontWeight:700}}>🔍 Pesquisa IA + Web</span><button onClick={()=>{navigator.clipboard?.writeText(iaResult);bibCacheAddLocal(iaResult);}} style={{padding:"4px 12px",background:"transparent",border:"1px solid #ddd9d0",borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:"#555"}}>📋 Copiar tudo</button></div>
                <div style={{fontSize:12,lineHeight:1.8,color:"#1a1a1a",fontFamily:"Georgia,serif",whiteSpace:"pre-wrap"}}>{iaResult}</div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
