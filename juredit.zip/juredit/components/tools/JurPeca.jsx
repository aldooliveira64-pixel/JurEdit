"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import mammoth from "mammoth";
import RichText from "../shared/RichText";
import { emptyP, wPara, wPFN, wFN, parseNN, SC, downloadDocx } from "../../lib/docx";

const TIPOS_PECA = {
  peticao:{label:"Petição",icon:"⚖️",cor:"#7c3aed",subtipos:["Petição Inicial","Contestação","Recurso de Apelação","Agravo de Instrumento","Embargos de Declaração","Recurso Especial","Recurso Extraordinário","Razões Finais"],modoDoc:"contestacao",acoes:[{ic:"📋",l:"Peça completa",p:"Pesquise legislação e jurisprudência (STF/STJ 2020–2025) e elabore a peça completa com estrutura processual padrão sobre: "},{ic:"📝",l:"Dos Fatos",p:"Redija a seção DOS FATOS de forma objetiva e cronológica para: "},{ic:"⚖️",l:"Do Direito",p:"Pesquise e elabore a seção DO DIREITO com fundamentos legais, doutrina e jurisprudência (notas ¹²³) sobre: "},{ic:"📜",l:"Dos Pedidos",p:"Elabore a seção DOS PEDIDOS completa e em ordem lógica para: "},{ic:"🚨",l:"Tutela de urgência",p:"Redija requerimento de tutela de urgência (art. 300 CPC): fumus boni iuris, periculum in mora, reversibilidade, para: "},{ic:"🔍",l:"Jurisprudência STF/STJ",p:"Pesquise jurisprudência STF e STJ 2020–2025 com número, relator, turma e data sobre: "}]},
  parecer:{label:"Parecer",icon:"📋",cor:"#0369a1",subtipos:["Parecer Jurídico","Nota Técnica Jurídica","Parecer em Processo Administrativo","Opinião Legal"],modoDoc:"parecer",acoes:[{ic:"📋",l:"Parecer completo",p:"Elabore parecer completo: EMENTA, I — DA CONSULTA, II — DO RELATÓRIO, III — DA FUNDAMENTAÇÃO, IV — DA CONCLUSÃO, notas ¹²³ ABNT, sobre: "},{ic:"📌",l:"Ementa do parecer",p:"Elabore a EMENTA do parecer: síntese precisa em até 5 linhas, sobre: "},{ic:"⚖️",l:"Fundamentação completa",p:"Pesquise doutrina + jurisprudência STF/STJ (2020–2025) e redija a FUNDAMENTAÇÃO com notas ¹²³, sobre: "},{ic:"✅",l:"Conclusão e matriz de risco",p:"Redija a CONCLUSÃO com análise de risco jurídico (baixo/médio/alto) e alternativas possíveis, sobre: "},{ic:"📚",l:"Doutrina e legislação",p:"Pesquise e cite doutrina + legislação vigente em 2025 sobre: "},{ic:"🔍",l:"Jurisprudência",p:"Pesquise jurisprudência STF, STJ e TRFs (2020–2025) com número, relator, turma, data, sobre: "}]},
  ementa:{label:"Ementa",icon:"📌",cor:"#065f46",subtipos:["Ementa de Acórdão","Ementa de Decisão Monocrática","Ementa de Parecer"],modoDoc:"julgado",acoes:[{ic:"📌",l:"Ementa completa",p:"Elabore ementa jurídica completa no padrão STJ/STF: área, ramos, questão, tese, dispositivo, resultado. Sobre: "},{ic:"🏛️",l:"Padrão STF",p:"Redija ementa no padrão STF com tese de repercussão geral quando aplicável. Sobre: "},{ic:"⚖️",l:"Padrão STJ",p:"Redija ementa no padrão STJ com súmula/precedente aplicável. Sobre: "},{ic:"🔑",l:"Palavras-chave",p:"Gere 6 a 10 palavras-chave jurídicas em ordem alfabética para: "},{ic:"✏️",l:"Aprimorar ementa",p:"Revise e aprimore a seguinte ementa:\n\n"},{ic:"📊",l:"Tese jurídica fixada",p:"Redija a tese jurídica fixada no formato de precedente vinculante sobre: "}]},
  contrato:{label:"Contrato",icon:"📄",cor:"#92400e",subtipos:["Contrato Civil","Contrato Empresarial","Minuta Contratual","Aditivo","Cláusula Específica","Distrato","Acordo Extrajudicial"],modoDoc:"parecer",acoes:[{ic:"📄",l:"Contrato completo",p:"Elabore contrato completo com qualificação, objeto, obrigações, prazo, valor, penalidades, rescisão e disposições gerais, sobre: "},{ic:"🎯",l:"Cláusula de objeto",p:"Redija a CLÁUSULA DE OBJETO com precisão técnica, para: "},{ic:"⚠️",l:"Penalidades e rescisão",p:"Redija as cláusulas de PENALIDADES, MULTAS e RESCISÃO, para: "},{ic:"🛡️",l:"Garantias e limitações",p:"Redija as cláusulas de GARANTIAS, RESPONSABILIDADE e LIMITAÇÃO DE DANOS, para: "},{ic:"📋",l:"Disposições gerais",p:"Redija as DISPOSIÇÕES GERAIS: foro, legislação aplicável, eleição de domicílio, para: "},{ic:"✏️",l:"Revisar cláusula",p:"Revise e aperfeiçoe a seguinte cláusula eliminando ambiguidades:\n\n"}]},
};
const AREAS=["Direito Processual Civil","Direito Processual Penal","Direito Civil","Direito Penal","Direito Tributário","Direito Administrativo","Direito Constitucional","Direito do Trabalho","Direito Empresarial","Direito do Consumidor","Direito Ambiental","Direito Previdenciário","Direito Digital","Direito Imobiliário","Direito Bancário","Mercado de Capitais"];
const NIVEIS=[{v:"Operadores do Direito (juízes, advogados, promotores)",l:"Operadores do Direito"},{v:"Doutorado e tratados acadêmicos de referência",l:"Doutorado / Tratado"},{v:"Mestrado e pós-graduação stricto sensu",l:"Mestrado / Pós-Grad."},{v:"Graduação avançada",l:"Graduação Avançada"}];
const MODOS_DOC={contestacao:{label:"Contestação / Defesa",icon:"🛡️",cor:"#7c3aed",instrucao:`Você recebeu uma PETIÇÃO INICIAL. Analise minuciosamente: pedidos, fundamentos jurídicos, fatos alegados, provas, vícios processuais. Elabore CONTESTAÇÃO COMPLETA com: I — DAS PRELIMINARES (vícios, prescrição), II — DA IMPUGNAÇÃO DOS FATOS, III — DO MÉRITO (improcedência), IV — DOS PEDIDOS. ② NOTAS DE RODAPÉ mínimo 15 notas ¹²³.`},recurso:{label:"Recurso estratégico",icon:"📤",cor:"#c45c1a",instrucao:`Você recebeu uma DECISÃO/ACÓRDÃO. Identifique: erros in procedendo (vício processual), erros in judicando, violação de lei federal (REsp art. 105 III CF), violação da CF (RE art. 102 III CF), divergência jurisprudencial. Para cada recurso cabível elabore razões recursais completas com fundamentos e jurisprudência.`},parecer:{label:"Análise de consulta",icon:"🔍",cor:"#0369a1",instrucao:`Você recebeu um DOCUMENTO DE CONSULTA. Elabore PARECER JURÍDICO COMPLETO: EMENTA / I — DA CONSULTA / II — DO RELATÓRIO / III — DA FUNDAMENTAÇÃO (cenário favorável, desfavorável, alternativas) / IV — DA CONCLUSÃO com matriz de risco (BAIXO/MÉDIO/ALTO). ② NOTAS DE RODAPÉ mínimo 15 notas ¹²³.`},julgado:{label:"Mineração de julgado",icon:"⛏️",cor:"#6b21a8",instrucao:`Você recebeu um ACÓRDÃO para análise estratégica. Extraia: ① RATIO DECIDENDI (tese central vinculante), ② OBITER DICTA (argumentos periféricos), ③ VOTOS VENCIDOS (oportunidade estratégica), ④ LACUNAS NÃO ENFRENTADAS, ⑤ DISTINGUISHING (como diferenciar), ⑥ TESES EXCLUSIVAS PARA APROVEITAMENTO ESTRATÉGICO. Como usar no próximo caso: script de argumentação pronto.`}};

function buildSystem(tipoKey,subtipo,area,nivel,temDoc){
  const tipo=TIPOS_PECA[tipoKey];
  return `Você é JurPeça Excellence v2 — redator e analista jurídico de máximo padrão técnico, com leitura de documentos e pesquisa web em tempo real.\n\nTipo: ${tipo.label} — ${subtipo}\nÁrea: ${area} | Nível: ${nivel}\n${temDoc?"MODO ANÁLISE DE DOCUMENTO: ativo — leia o documento antes de qualquer resposta.":""}\n\nREGRAS ABSOLUTAS:\n✗ NUNCA invente número de processo, relator, data, autor ou obra\n✓ Jurisprudência somente STF/STJ/TRFs 2020–2025 confirmada\n✓ Notas superscript ¹²³ — NUNCA [1] ou (1)\n✓ Legislação: versão vigente em 2025\n✓ Ao final: ② NOTAS DE RODAPÉ\n\nESTILO: técnico-jurídico preciso · voz impessoal · termos latinos em *itálico*`;
}

export default function JurPeca() {
  const[tipoKey,setTipoKey]=useState("peticao");
  const[subtipo,setSubtipo]=useState(TIPOS_PECA.peticao.subtipos[0]);
  const[area,setArea]=useState("Direito Processual Civil");
  const[nivel,setNivel]=useState(NIVEIS[0].v);
  const[titulo,setTitulo]=useState("");
  const[msgs,setMsgs]=useState([]);
  const[input,setInput]=useState("");
  const[loading,setLoading]=useState(false);
  const[exportStatus,setExportStatus]=useState("idle");
  const[sideOpen,setSideOpen]=useState(true);
  const[docs,setDocs]=useState([]);
  const[modoDoc,setModoDoc]=useState("contestacao");
  const[uploadErr,setUploadErr]=useState("");
  const[uploadLoading,setUploadLoading]=useState(false);
  const[showUpload,setShowUpload]=useState(false);
  const fileInputRef=useRef(null);
  const bottomRef=useRef(null);
  const taRef=useRef(null);
  const tipo=TIPOS_PECA[tipoKey];

  useEffect(()=>{setSubtipo(TIPOS_PECA[tipoKey].subtipos[0]);setModoDoc(TIPOS_PECA[tipoKey].modoDoc);setMsgs([]);setDocs([]);},[tipoKey]);
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,loading]);
  useEffect(()=>{if(taRef.current){taRef.current.style.height="auto";taRef.current.style.height=Math.min(taRef.current.scrollHeight,160)+"px";}},[input]);

  const handleFiles=async(files)=>{
    if(!files?.length)return;
    setUploadErr("");setUploadLoading(true);
    const novos=[];
    for(const file of Array.from(files)){
      if(docs.length+novos.length>=3){setUploadErr("Máximo 3 arquivos.");break;}
      if(file.size>30*1024*1024){setUploadErr(`${file.name}: muito grande (máx. 30MB).`);continue;}
      try{
        const ext=file.name.split(".").pop().toLowerCase();
        if(ext==="pdf"){await new Promise((res,rej)=>{const r=new FileReader();r.onload=e=>{novos.push({tipo:"pdf",base64:e.target.result.split(",")[1],nome:file.name,size:file.size,id:Date.now()+Math.random(),modoKey:modoDoc});res();};r.onerror=rej;r.readAsDataURL(file);});}
        else if(["docx","doc"].includes(ext)){await new Promise((res,rej)=>{const r=new FileReader();r.onload=async e=>{const x=await mammoth.extractRawText({arrayBuffer:e.target.result});novos.push({tipo:"docx",texto:x.value,nome:file.name,size:file.size,id:Date.now()+Math.random(),modoKey:modoDoc});res();};r.onerror=rej;r.readAsArrayBuffer(file);});}
        else setUploadErr("Use PDF ou DOCX.");
      }catch(e){setUploadErr(e.message||"Erro ao ler o arquivo.");}
    }
    setDocs(prev=>[...prev,...novos]);setUploadLoading(false);if(novos.length)setShowUpload(false);
  };

  const montarContentDoc=(doc,instrucaoExtra)=>{
    const modo=MODOS_DOC[doc.modoKey];
    const instrucao=modo.instrucao+(instrucaoExtra?`\n\nINSTRUÇÃO ADICIONAL: ${instrucaoExtra}`:"");
    if(doc.tipo==="pdf")return[{type:"document",source:{type:"base64",media_type:"application/pdf",data:doc.base64}},{type:"text",text:instrucao}];
    return[{type:"text",text:`DOCUMENTO (${doc.nome}):\n\n${doc.texto.slice(0,30000)}\n\n---\n\n${instrucao}`}];
  };

  const enviar=useCallback(async(texto)=>{
    const prompt=texto||input.trim();
    if(!prompt&&!docs.length)return;
    if(loading)return;
    setInput("");
    const apiContent=docs.length?[...montarContentDoc(docs[0],prompt),...docs.slice(1).flatMap(d=>montarContentDoc(d,""))]:prompt;
    const novasMsgs=[...msgs,{role:"user",content:typeof apiContent==="string"?apiContent:prompt,docContent:docs.length?apiContent:null,docNomes:docs.map(d=>d.nome)}];
    setMsgs(novasMsgs);setLoading(true);
    try{
      const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:buildSystem(tipoKey,subtipo,area,nivel,docs.length>0),messages:novasMsgs.map(m=>({role:m.role,content:m.docContent||m.content})),tools:[{type:"web_search_20250305",name:"web_search"}]})});
      const data=await resp.json();
      const txt=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim();
      setMsgs(prev=>[...prev,{role:"assistant",content:txt||"Sem resposta."}]);setDocs([]);
    }catch(e){setMsgs(prev=>[...prev,{role:"assistant",content:"❌ Erro de conexão."}]);}
    finally{setLoading(false);}
  },[msgs,input,loading,tipoKey,subtipo,area,nivel,docs]);

  const handleExport=async()=>{
    const conteudo=msgs.filter(m=>m.role==="assistant").map(m=>m.content).join("\n\n");
    if(!conteudo.trim())return;
    setExportStatus("loading");
    try{
      const lines=conteudo.split("\n");const noteIdx=lines.findIndex(l=>/^②?\s*NOTAS?\s*DE\s*RODAP/i.test(l.trim()));
      const bodyLines=noteIdx>-1?lines.slice(0,noteIdx):lines;const fm={};
      const paras=[emptyP(),emptyP()];
      paras.push(wPara([{text:tipo.label+" · "+area,bold:false,italic:true,sup:false}],{center:true,sizePt:10,spaceAfter:40,lineVal:240}));
      paras.push(wPara([{text:titulo||subtipo,bold:true,italic:false,sup:false}],{center:true,sizePt:16,spaceBefore:40,spaceAfter:120,lineVal:280}));
      paras.push(wPara([{text:"",bold:false,italic:false,sup:false}],{center:true,sizePt:10,spaceBefore:20,spaceAfter:20,border:true}));paras.push(emptyP());
      for(const line of bodyLines){
        const raw=line.trim();if(!raw){paras.push(emptyP());continue;}
        if(/^-{3,}$/.test(raw)){paras.push(`<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr><w:spacing w:before="120" w:after="120"/></w:pPr></w:p>`);continue;}
        if(raw===raw.toUpperCase()&&/[A-ZÁÉÍÓÚ]{4,}/.test(raw)&&raw.length>4&&raw.length<120&&!/^\d/.test(raw)&&!/^[①②③④⑤]/.test(raw)){paras.push(wPara([{text:raw,bold:true,italic:false,sup:false}],{align:"left",sizePt:12,spaceBefore:300,spaceAfter:100,lineVal:276}));continue;}
        if(/^\*\*[^*]+\*\*$/.test(raw)){paras.push(wPara([{text:raw.replace(/\*\*/g,""),bold:true,italic:false,sup:false}],{align:"left",sizePt:12,spaceBefore:300,spaceAfter:100,lineVal:276}));continue;}
        if(/^>\s*/.test(raw)){paras.push(wPFN(raw.replace(/^>\s*/,""),{align:"both",sizePt:9,spaceBefore:80,spaceAfter:80,lineVal:240,indentLeft:709,indentRight:709},fm));continue;}
        const rc=raw.replace(/\*\*/g,"").trim();if(/^[①②③④⑤]/.test(rc)||/^NOTAS?\s*DE\s*RODAP/i.test(rc))continue;
        if((SC.includes(raw[0])||/^\d{1,2}[.\)]\s/.test(raw))&&raw.length<400){const p=parseNN(raw);if(p&&p.text.length>8)continue;}
        paras.push(wPFN(raw,{align:"both",sizePt:12,indent:709,spaceBefore:0,spaceAfter:60,lineVal:276},fm));
      }
      const fnE=Object.entries(fm).sort((a,b)=>Number(a[0])-Number(b[0]));
      const slug=(titulo||subtipo||"JurPeca").replace(/[^a-zA-Z0-9]/g,"_").slice(0,30);
      downloadDocx(paras,(titulo||subtipo).slice(0,80),fnE,slug+"_"+new Date().toISOString().slice(0,10)+".docx");
      setExportStatus("done");setTimeout(()=>setExportStatus("idle"),5000);
    }catch(e){console.error(e);setExportStatus("error");setTimeout(()=>setExportStatus("idle"),3000);}
  };

  const hasContent=msgs.some(m=>m.role==="assistant");
  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999",cor:tipo.cor};

  return(
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      <div style={{background:C.nav,padding:"0 18px",display:"flex",alignItems:"center",gap:10,height:48,flexShrink:0,borderBottom:"1px solid #0a1020"}}>
        <button onClick={()=>setSideOpen(v=>!v)} style={{background:"none",border:"none",color:"rgba(255,255,255,.5)",cursor:"pointer",fontSize:16}}>☰</button>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JURPEÇA</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v2 · docs</span>
        <span style={{fontSize:12,color:"rgba(255,255,255,.6)"}}>{tipo.icon} {tipo.label} · {subtipo}</span>
        <div style={{marginLeft:"auto",display:"flex",gap:8}}>
          {hasContent&&<button onClick={handleExport} disabled={exportStatus==="loading"} style={{padding:"5px 14px",background:exportStatus==="done"?"#166534":tipo.cor,color:"white",border:"none",borderRadius:3,fontSize:11,fontFamily:"monospace",cursor:"pointer"}}>{exportStatus==="loading"?"⏳...":exportStatus==="done"?"✅ gerado!":"⬇ .docx"}</button>}
          {msgs.length>0&&<button onClick={()=>{if(window.confirm("Limpar?"))setMsgs([]);}} style={{padding:"5px 10px",background:"transparent",color:"rgba(255,255,255,.25)",border:"1px solid rgba(255,255,255,.08)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>limpar</button>}
        </div>
      </div>
      <div style={{flex:1,display:"flex",overflow:"hidden"}}>
        {sideOpen&&(
          <div style={{width:240,background:C.white,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
            <div style={{padding:"12px 14px 10px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:6}}>Tipo de peça</div>
              {Object.entries(TIPOS_PECA).map(([k,t])=>(
                <button key={k} onClick={()=>setTipoKey(k)} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:"7px 10px",marginBottom:3,border:"none",borderRadius:4,cursor:"pointer",textAlign:"left",background:tipoKey===k?`${t.cor}15`:"transparent",color:tipoKey===k?t.cor:C.textSec,fontWeight:tipoKey===k?700:400,borderLeft:tipoKey===k?`3px solid ${t.cor}`:"3px solid transparent",fontSize:13,fontFamily:"Georgia,serif",transition:"all .15s"}}>
                  {t.icon} {t.label}
                </button>
              ))}
            </div>
            <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Subtipo</div>
              <select value={subtipo} onChange={e=>setSubtipo(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:12,background:C.bg,outline:"none",marginBottom:8}}>
                {tipo.subtipos.map(s=><option key={s} value={s}>{s}</option>)}
              </select>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Área</div>
              <select value={area} onChange={e=>setArea(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:12,background:C.bg,outline:"none",marginBottom:8}}>
                {AREAS.map(a=><option key={a} value={a}>{a}</option>)}
              </select>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Título (.docx)</div>
              <input value={titulo} onChange={e=>setTitulo(e.target.value)} placeholder={subtipo} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:12,background:C.bg,outline:"none",boxSizing:"border-box"}}/>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"10px 14px"}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:6}}>Ações rápidas</div>
              {tipo.acoes.map((a,i)=>(
                <button key={i} onClick={()=>enviar(a.p)} style={{display:"flex",alignItems:"flex-start",gap:7,width:"100%",padding:"7px 9px",marginBottom:4,border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",textAlign:"left",background:"transparent",color:C.textSec,fontSize:11,fontFamily:"Georgia,serif",lineHeight:1.4,transition:"all .12s"}} onMouseOver={e=>{e.currentTarget.style.background=`${tipo.cor}10`;e.currentTarget.style.color=C.textPri;}} onMouseOut={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color=C.textSec;}}>
                  <span style={{flexShrink:0}}>{a.ic}</span><span>{a.l}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          {showUpload&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"14px 20px",flexShrink:0}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:12,fontWeight:500}}>Modo de análise</span><button onClick={()=>setShowUpload(false)} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:C.textTer}}>×</button></div>
              <div style={{display:"flex",gap:6,marginBottom:8,flexWrap:"wrap"}}>
                {Object.entries(MODOS_DOC).map(([k,m])=>(
                  <button key={k} onClick={()=>setModoDoc(k)} style={{padding:"4px 10px",border:`1px solid ${modoDoc===k?m.cor:C.border}`,borderRadius:20,fontSize:10,fontFamily:"monospace",cursor:"pointer",background:modoDoc===k?`${m.cor}12`:"transparent",color:modoDoc===k?m.cor:C.textSec,fontWeight:modoDoc===k?700:400}}>
                    {m.icon} {m.label}
                  </button>
                ))}
              </div>
              <div onDrop={e=>{e.preventDefault();handleFiles(e.dataTransfer.files);}} onDragOver={e=>e.preventDefault()} onClick={()=>fileInputRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:8,padding:"16px",textAlign:"center",cursor:"pointer",background:"#faf8f4"}}>
                {uploadLoading?<div style={{fontSize:13,color:C.textSec}}>⏳ Lendo arquivo...</div>:<><div style={{fontSize:24,marginBottom:4}}>📄</div><div style={{fontSize:12,color:C.textSec}}>Arraste PDF ou DOCX · ou clique · máx. 30MB · até 3 arquivos</div></>}
              </div>
              <input ref={fileInputRef} type="file" accept=".pdf,.docx,.doc" multiple style={{display:"none"}} onChange={e=>handleFiles(e.target.files)}/>
              {uploadErr&&<div style={{marginTop:6,fontSize:11,color:"#991b1b",fontFamily:"monospace"}}>❌ {uploadErr}</div>}
              {docs.length>0&&<div style={{marginTop:8}}>{docs.map(d=><div key={d.id} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 8px",background:`${MODOS_DOC[d.modoKey].cor}10`,border:`1px solid ${MODOS_DOC[d.modoKey].cor}30`,borderRadius:6,marginBottom:4,fontSize:11,fontFamily:"monospace",color:MODOS_DOC[d.modoKey].cor}}>{d.tipo==="pdf"?"📕":"📝"} {d.nome.slice(0,25)} · {MODOS_DOC[d.modoKey].icon}<button onClick={()=>setDocs(prev=>prev.filter(x=>x.id!==d.id))} style={{marginLeft:"auto",background:"none",border:"none",cursor:"pointer",color:"inherit",fontSize:12}}>×</button></div>)}</div>}
            </div>
          )}
          {!showUpload&&docs.length>0&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"7px 18px",display:"flex",gap:8,alignItems:"center",flexShrink:0,flexWrap:"wrap"}}>
              <span style={{fontSize:10,fontFamily:"monospace",color:C.textTer}}>Docs:</span>
              {docs.map(d=><span key={d.id} style={{display:"inline-flex",alignItems:"center",gap:4,padding:"3px 10px",background:`${MODOS_DOC[d.modoKey].cor}12`,border:`1px solid ${MODOS_DOC[d.modoKey].cor}30`,borderRadius:12,fontSize:11,fontFamily:"monospace",color:MODOS_DOC[d.modoKey].cor}}>
                {d.tipo==="pdf"?"📕":"📝"} {d.nome.slice(0,20)} · {MODOS_DOC[d.modoKey].icon}
                <button onClick={()=>setDocs(prev=>prev.filter(x=>x.id!==d.id))} style={{background:"none",border:"none",cursor:"pointer",color:"inherit",fontSize:12,padding:"0 0 0 4px"}}>×</button>
              </span>)}
            </div>
          )}
          <div style={{flex:1,overflowY:"auto",padding:"20px 24px"}}>
            {msgs.length===0&&(
              <div style={{maxWidth:540,margin:"40px auto 0",textAlign:"center"}}>
                <div style={{fontSize:36,marginBottom:10}}>{tipo.icon}</div>
                <div style={{fontSize:18,fontWeight:700,marginBottom:6}}>{tipo.label} v2</div>
                <div style={{fontSize:13,color:C.textSec,lineHeight:1.7,marginBottom:16}}>{subtipo} · {area}</div>
                <div style={{marginBottom:14,padding:"10px 14px",background:"#eff6ff",border:"1px solid #bfdbfe",borderRadius:6,fontSize:12,color:"#1e40af",textAlign:"left"}}>
                  💡 Use 📎 para carregar PDF/DOCX (petição, parecer, acórdão) — a IA analisa e elabora a resposta estratégica.
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,textAlign:"left"}}>
                  {tipo.acoes.slice(0,4).map((a,i)=><button key={i} onClick={()=>enviar(a.p)} style={{padding:"10px 12px",border:`1px solid ${C.border}`,borderRadius:6,cursor:"pointer",background:C.white,textAlign:"left",fontSize:12,color:C.textSec,fontFamily:"Georgia,serif",lineHeight:1.4}} onMouseOver={e=>{e.currentTarget.style.borderColor=tipo.cor;}} onMouseOut={e=>{e.currentTarget.style.borderColor=C.border;}}>{a.ic} {a.l}</button>)}
                </div>
              </div>
            )}
            {msgs.map((m,i)=>(
              <div key={i} style={{marginBottom:20,display:"flex",gap:12,justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                {m.role==="assistant"&&<div style={{width:28,height:28,background:tipo.cor,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0,marginTop:2}}>{tipo.icon}</div>}
                <div style={{maxWidth:"82%"}}>
                  {m.docNomes?.length>0&&<div style={{display:"flex",gap:6,marginBottom:4,justifyContent:"flex-end"}}>{m.docNomes.map((n,j)=><span key={j} style={{fontSize:10,fontFamily:"monospace",padding:"2px 8px",background:`${tipo.cor}15`,border:`1px solid ${tipo.cor}30`,borderRadius:10,color:tipo.cor}}>📄 {n.slice(0,18)}</span>)}</div>}
                  <div style={{padding:"12px 16px",borderRadius:m.role==="user"?"16px 4px 16px 16px":"4px 16px 16px 16px",background:m.role==="user"?C.nav:C.white,color:m.role==="user"?"white":C.textPri,border:m.role==="assistant"?`1px solid ${C.border}`:"none",fontSize:13,lineHeight:1.75}}>
                    {m.role==="assistant"?<RichText content={m.content}/>:<span style={{fontFamily:"Georgia,serif",fontSize:13}}>{typeof m.content==="string"?m.content:"[documento enviado]"}</span>}
                  </div>
                </div>
              </div>
            ))}
            {loading&&<div style={{display:"flex",gap:12,marginBottom:20}}><div style={{width:28,height:28,background:tipo.cor,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>{tipo.icon}</div><div style={{padding:"12px 16px",background:C.white,border:`1px solid ${C.border}`,borderRadius:"4px 16px 16px 16px",display:"flex",gap:6,alignItems:"center"}}>{[0,1,2].map(j=><div key={j} style={{width:7,height:7,borderRadius:"50%",background:tipo.cor,opacity:.5,animation:`bounce 1.2s ease-in-out ${j*.2}s infinite`}}/>)}</div></div>}
            <div ref={bottomRef}/>
          </div>
          <div style={{borderTop:`1px solid ${C.border}`,background:C.white,padding:"12px 18px"}}>
            <div style={{display:"flex",gap:8,alignItems:"flex-end",maxWidth:880,margin:"0 auto"}}>
              <button onClick={()=>setShowUpload(v=>!v)} title="Carregar PDF ou DOCX" style={{width:40,height:40,display:"flex",alignItems:"center",justifyContent:"center",border:`1px solid ${docs.length>0?tipo.cor:C.border}`,borderRadius:8,cursor:"pointer",background:docs.length>0?`${tipo.cor}15`:C.bg,color:docs.length>0?tipo.cor:C.textTer,fontSize:18,flexShrink:0,position:"relative"}}>
                📎{docs.length>0&&<span style={{position:"absolute",top:-6,right:-6,width:16,height:16,background:tipo.cor,borderRadius:"50%",fontSize:9,fontWeight:700,color:"white",display:"flex",alignItems:"center",justifyContent:"center"}}>{docs.length}</span>}
              </button>
              <textarea ref={taRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();enviar();}}} placeholder={docs.length>0?"Instrução adicional... (ou envie sem texto para análise direta)":"Descreva a situação... (Enter para enviar)"} rows={1} style={{flex:1,padding:"10px 14px",border:`1px solid ${C.border}`,borderRadius:8,fontFamily:"Georgia,serif",fontSize:13,resize:"none",outline:"none",lineHeight:1.6,overflow:"hidden",background:C.bg,color:C.textPri}} onFocus={e=>e.target.style.borderColor=tipo.cor} onBlur={e=>e.target.style.borderColor=C.border}/>
              <button onClick={()=>enviar()} disabled={loading||(!input.trim()&&!docs.length)} style={{padding:"10px 18px",background:loading||(!input.trim()&&!docs.length)?"#ccc":tipo.cor,color:"white",border:"none",borderRadius:8,cursor:loading||(!input.trim()&&!docs.length)?"not-allowed":"pointer",fontSize:16,flexShrink:0,height:40}}>↑</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
