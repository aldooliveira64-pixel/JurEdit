"use client";
import { useState, useEffect } from "react";
import { storageGet, storageSet } from "../../lib/storage";
import { emptyP, wPara, wPFN, wFN, parseNN, SC, downloadDocx } from "../../lib/docx";

const K_PROJ="jura-obra-project-v1", K_JUR="jura-jur-cache", K_BIB="jura-bib-cache", K_CAPS="jura-chapters-cache";
const PROJ_DEF={ nome:"", area:"", autores:"", capsOk:[], capsProx:[] };

export default function JurHub() {
  const [proj, setProj]         = useState(PROJ_DEF);
  const [jurCache, setJurCache] = useState([]);
  const [bibCache, setBibCache] = useState([]);
  const [capsTexto, setCapsTexto]= useState("");
  const [jurInput, setJurInput] = useState("");
  const [bibInput, setBibInput] = useState("");
  const [loading, setLoading]   = useState(true);
  const [saved, setSaved]       = useState({});
  const [exportStatus, setExportStatus] = useState("idle");
  const [aba, setAba]           = useState("dashboard");
  const [editProj, setEditProj] = useState(false);
  const [projEdit, setProjEdit] = useState(PROJ_DEF);
  const [copiedJur, setCopiedJur]= useState(null);
  const [copiedBib, setCopiedBib]= useState(null);

  useEffect(() => {
    (async () => {
      const [p,j,b,c] = await Promise.all([storageGet(K_PROJ),storageGet(K_JUR),storageGet(K_BIB),storageGet(K_CAPS)]);
      if(p) setProj(p);
      if(j) setJurCache(Array.isArray(j)?j:[]);
      if(b) setBibCache(Array.isArray(b)?b:[]);
      if(c) setCapsTexto(typeof c==="string"?c:"");
      setLoading(false);
    })();
  }, []);

  const salvarProj = async (p) => {
    setProj(p); setEditProj(false);
    await storageSet(K_PROJ, p);
    setSaved(s=>({...s,proj:"ok"})); setTimeout(()=>setSaved(s=>({...s,proj:null})),3000);
  };
  const addJur = async () => {
    const txt=jurInput.trim(); if(!txt) return;
    const nova=[...jurCache,{id:Date.now(),texto:txt,ts:new Date().toLocaleDateString("pt-BR")}];
    setJurCache(nova); setJurInput(""); await storageSet(K_JUR,nova);
    setSaved(s=>({...s,jur:"ok"})); setTimeout(()=>setSaved(s=>({...s,jur:null})),2500);
  };
  const remJur = async (id) => { const n=jurCache.filter(x=>x.id!==id); setJurCache(n); await storageSet(K_JUR,n); };
  const addBib = async () => {
    const txt=bibInput.trim(); if(!txt) return;
    const nova=[...bibCache,{id:Date.now(),texto:txt,ts:new Date().toLocaleDateString("pt-BR")}];
    setBibCache(nova); setBibInput(""); await storageSet(K_BIB,nova);
    setSaved(s=>({...s,bib:"ok"})); setTimeout(()=>setSaved(s=>({...s,bib:null})),2500);
  };
  const remBib = async (id) => { const n=bibCache.filter(x=>x.id!==id); setBibCache(n); await storageSet(K_BIB,n); };
  const salvarCaps = async (txt) => { setCapsTexto(txt); await storageSet(K_CAPS,txt); };

  const exportarObra = async () => {
    if(!capsTexto.trim()) return;
    setExportStatus("loading");
    try {
      const lines=capsTexto.split("\n");
      const noteIdx=lines.findIndex(l=>/^②?\s*NOTAS?\s*DE\s*RODAP/i.test(l.trim()));
      const bodyLines=noteIdx>-1?lines.slice(0,noteIdx):lines;
      const fm={};
      const paras=[emptyP(),emptyP(),emptyP()];
      if(proj.area) paras.push(wPara([{text:proj.area,bold:false,italic:true,sup:false}],{center:true,sizePt:11,spaceAfter:60,lineVal:240}));
      paras.push(wPara([{text:proj.nome||"Obra Jurídica",bold:true,italic:false,sup:false}],{center:true,sizePt:22,spaceBefore:60,spaceAfter:160,lineVal:280}));
      if(proj.autores) paras.push(wPara([{text:proj.autores,bold:false,italic:false,sup:false}],{center:true,sizePt:11,spaceAfter:40,lineVal:240}));
      paras.push(emptyP());
      const allCaps=[...proj.capsOk.map((c,i)=>({label:c,ok:true})),...proj.capsProx.map(c=>({label:`Cap. ${c.num} — ${c.titulo}`,ok:false}))];
      if(allCaps.length>0){
        paras.push(wPara([{text:"SUMÁRIO",bold:true,italic:false,sup:false}],{center:true,sizePt:14,spaceBefore:80,spaceAfter:200,lineVal:240}));
        for(const c of allCaps) paras.push(wPara([{text:(c.ok?"✓  ":"")+c.label,bold:false,italic:false,sup:false}],{align:"left",sizePt:11,spaceBefore:60,spaceAfter:40,lineVal:240}));
        paras.push(emptyP(),`<w:p><w:pPr><w:pageBreakBefore/></w:pPr></w:p>`);
      }
      for(const line of bodyLines){
        const raw=line.trim(); if(!raw){paras.push(emptyP());continue;}
        if(/^-{3,}$/.test(raw)){paras.push(`<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr><w:spacing w:before="120" w:after="120"/></w:pPr></w:p>`);continue;}
        if(raw===raw.toUpperCase()&&/[A-ZÁÉÍÓÚ]{4,}/.test(raw)&&raw.length>4&&raw.length<120&&!/^\d/.test(raw)&&!/^[①②③④⑤]/.test(raw)){paras.push(wPara([{text:raw,bold:true,italic:false,sup:false}],{center:true,sizePt:14,spaceAfter:360,lineVal:240}));continue;}
        if(/^\*\*[^*]+\*\*$/.test(raw)){paras.push(wPara([{text:raw.replace(/\*\*/g,""),bold:true,italic:false,sup:false}],{align:"left",sizePt:12,spaceBefore:360,spaceAfter:120,lineVal:276}));continue;}
        if(/^>\s*/.test(raw)){paras.push(wPFN(raw.replace(/^>\s*/,""),{align:"both",sizePt:9,spaceBefore:80,spaceAfter:80,lineVal:240,indentLeft:709,indentRight:709},fm));continue;}
        const rc=raw.replace(/\*\*/g,"").trim();
        if(/^[①②③④⑤]/.test(rc)||/^NOTAS?\s*DE\s*RODAP/i.test(rc))continue;
        if((SC.includes(raw[0])||/^\d{1,2}[.\)]\s/.test(raw))&&raw.length<400){const p=parseNN(raw);if(p&&p.text.length>10)continue;}
        paras.push(wPFN(raw,{align:"both",sizePt:12,indent:709,spaceBefore:0,spaceAfter:60,lineVal:276},fm));
      }
      const fnE=Object.entries(fm).sort((a,b)=>Number(a[0])-Number(b[0]));
      const hTxt=(proj.nome||"Obra Jurídica").slice(0,80);
      const slug=(proj.nome||"JurObra").replace(/[^a-zA-Z0-9]/g,"_").slice(0,30);
      downloadDocx(paras, hTxt, fnE, slug+"_COMPLETO_"+new Date().toISOString().slice(0,10)+".docx");
      setExportStatus("done"); setTimeout(()=>setExportStatus("idle"),6000);
    } catch(e){ console.error(e); setExportStatus("error"); setTimeout(()=>setExportStatus("idle"),4000); }
  };

  const prog=proj.capsOk.length, total=proj.capsOk.length+proj.capsProx.length;
  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999",green:"#166534"};
  const inp={width:"100%",padding:"8px 12px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:13,color:C.textPri,background:C.white,outline:"none",boxSizing:"border-box"};
  const btnNav=(id)=>({padding:"9px 18px",fontSize:12,fontFamily:"monospace",letterSpacing:".05em",border:"none",background:aba===id?C.white:"transparent",cursor:"pointer",color:aba===id?C.nav:C.textTer,fontWeight:aba===id?700:400,borderBottom:aba===id?`2px solid ${C.gold}`:"2px solid transparent",marginBottom:-1,transition:"all .15s"});

  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",background:C.bg}}><div style={{textAlign:"center"}}><div style={{fontSize:28,marginBottom:10}}>🏠</div><div style={{fontSize:13,color:C.textSec,fontFamily:"monospace"}}>carregando...</div></div></div>;

  return (
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      {/* Top */}
      <div style={{background:C.nav,padding:"0 22px",display:"flex",alignItems:"center",gap:12,height:48,flexShrink:0}}>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JURHUB</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v1 · centro de controle</span>
        {saved.proj&&<span style={{fontSize:10,color:"#4ade80",fontFamily:"monospace"}}>● projeto salvo</span>}
        <div style={{marginLeft:"auto"}}>
          <button onClick={()=>{setProjEdit({...proj});setEditProj(true);}} style={{padding:"5px 14px",background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.6)",border:"1px solid rgba(255,255,255,.12)",borderRadius:3,fontSize:11,fontFamily:"monospace",cursor:"pointer"}}>⚙️ Editar Projeto</button>
        </div>
      </div>

      <div style={{maxWidth:980,margin:"0 auto",padding:"20px 18px",width:"100%",boxSizing:"border-box",flex:1,overflowY:"auto"}}>
        {/* Stats */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:16}}>
          {[["Capítulos ✓",prog,"#166534"],[`/${total} total`,total>0?`${Math.round((prog/total)*100)}%`:"0%","#c49a2a"],["Citações salvas",jurCache.length,"#0369a1"],["Referências salvas",bibCache.length,"#c49a2a"]].map(([label,val,cor],i)=>(
            <div key={i} style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,padding:"12px",textAlign:"center"}}>
              <div style={{fontSize:22,fontWeight:700,color:cor,lineHeight:1}}>{val}</div>
              <div style={{fontSize:11,color:C.textSec,marginTop:4,fontFamily:"monospace"}}>{label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{display:"flex",borderBottom:`1px solid ${C.border}`,marginBottom:16}}>
          {[["dashboard","📊 Dashboard"],["bancos","🏦 Bancos"],["export","📄 Export"]].map(([id,label])=>(
            <button key={id} onClick={()=>setAba(id)} style={btnNav(id)}>{label}</button>
          ))}
        </div>

        {/* Dashboard */}
        {aba==="dashboard"&&(
          <div>
            {!proj.nome?(
              <div style={{textAlign:"center",padding:"40px 0"}}>
                <div style={{fontSize:32,marginBottom:10}}>📚</div>
                <div style={{fontSize:14,color:C.textSec,marginBottom:16}}>Nenhum projeto configurado</div>
                <button onClick={()=>{setProjEdit({...PROJ_DEF});setEditProj(true);}} style={{padding:"10px 24px",background:C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>⚙️ Configurar Projeto</button>
              </div>
            ):(
              <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,padding:"20px"}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
                  <div>
                    <div style={{fontSize:11,color:C.textTer,fontFamily:"monospace",marginBottom:4}}>OBRA</div>
                    <div style={{fontSize:20,fontWeight:700,color:C.textPri,marginBottom:6}}>{proj.nome}</div>
                    {proj.area&&<div style={{fontSize:12,color:C.textSec,marginBottom:2}}>📍 {proj.area}</div>}
                    {proj.autores&&<div style={{fontSize:12,color:C.textSec}}>✍️ {proj.autores}</div>}
                  </div>
                  <div>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                      <span style={{fontSize:10,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase"}}>Progresso</span>
                      <span style={{fontSize:12,fontWeight:700,color:C.gold,fontFamily:"monospace"}}>{prog}/{total}</span>
                    </div>
                    <div style={{height:6,background:"#ede8df",borderRadius:3,marginBottom:10,overflow:"hidden"}}>
                      <div style={{height:"100%",background:C.gold,borderRadius:3,width:total>0?`${(prog/total)*100}%`:"0%",transition:"width .5s"}}/>
                    </div>
                    {proj.capsOk.map((c,i)=><div key={i} style={{fontSize:11,color:C.green,fontFamily:"monospace",padding:"1px 0"}}>✓ {c.slice(0,50)}</div>)}
                    {proj.capsProx.slice(0,4).map((c,i)=><div key={i} style={{fontSize:11,color:C.textTer,fontFamily:"monospace",padding:"1px 0"}}>→ Cap. {c.num} — {c.titulo.slice(0,36)}</div>)}
                  </div>
                </div>
              </div>
            )}
            {/* Fluxo rápido */}
            <div style={{marginTop:14,background:C.white,border:`1px solid ${C.border}`,borderRadius:8,padding:"16px 20px"}}>
              <div style={{fontSize:10,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:10}}>Fluxo de trabalho</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
                {["1 Configure o projeto aqui","2 Pesquise em JurJurisprudência e JurBiblioteca","3 Os resultados copiados aparecem nos bancos","4 Cole capítulos em Export → baixe a obra"].map((s,i)=>(
                  <div key={i} style={{padding:"10px 12px",background:"#f7f3ec",borderRadius:6,fontSize:11,color:C.textSec,lineHeight:1.6}}>
                    <strong style={{color:C.nav,display:"block",marginBottom:4,fontFamily:"monospace"}}>Passo {i+1}</strong>{s.slice(2)}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Bancos */}
        {aba==="bancos"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
            {/* Jurisprudência */}
            <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,overflow:"hidden"}}>
              <div style={{background:"#eff6ff",borderBottom:`1px solid ${C.border}`,padding:"10px 16px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <span style={{fontSize:11,fontWeight:700,color:"#0369a1"}}>⚖️ Citações — {jurCache.length}</span>
                {saved.jur&&<span style={{fontSize:10,color:C.green,fontFamily:"monospace"}}>● salvo</span>}
                {jurCache.length>0&&<button onClick={()=>{navigator.clipboard?.writeText(jurCache.map(j=>j.texto).join("\n\n"));setCopiedJur("all");setTimeout(()=>setCopiedJur(null),2500);}} style={{padding:"3px 10px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",fontSize:10,fontFamily:"monospace",color:C.textSec}}>{copiedJur==="all"?"✅":"📋 Copiar todas"}</button>}
              </div>
              <div style={{padding:"12px"}}>
                <textarea value={jurInput} onChange={e=>setJurInput(e.target.value)} placeholder="Cole a citação do JurJurisprudência..." style={{...inp,minHeight:70,resize:"vertical",lineHeight:1.6,fontSize:12}}/>
                <button onClick={addJur} disabled={!jurInput.trim()} style={{width:"100%",marginTop:8,padding:"7px",background:"#0369a1",color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:12,fontFamily:"monospace",opacity:jurInput.trim()?1:.4}}>+ Adicionar</button>
              </div>
              <div style={{borderTop:`1px solid ${C.border}`,maxHeight:250,overflowY:"auto"}}>
                {jurCache.length===0?<div style={{padding:"20px",textAlign:"center",color:C.textTer,fontSize:12}}>Nenhuma citação</div>:jurCache.map((j,i)=>(
                  <div key={j.id} style={{padding:"8px 12px",borderBottom:i<jurCache.length-1?`1px solid ${C.border}`:"none",display:"flex",gap:8,alignItems:"flex-start"}}>
                    <span style={{fontSize:10,fontFamily:"monospace",color:C.textTer,flexShrink:0}}>{i+1}.</span>
                    <div style={{flex:1,fontSize:11,color:C.textSec,lineHeight:1.5}}>{j.texto}</div>
                    <div style={{display:"flex",gap:3,flexShrink:0}}>
                      <button onClick={()=>{navigator.clipboard?.writeText(j.texto);setCopiedJur(j.id);setTimeout(()=>setCopiedJur(null),2000);}} style={{padding:"2px 6px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:3,cursor:"pointer",fontSize:9,fontFamily:"monospace",color:C.textSec}}>{copiedJur===j.id?"✅":"📋"}</button>
                      <button onClick={()=>remJur(j.id)} style={{padding:"2px 6px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:3,cursor:"pointer",fontSize:9,color:"#991b1b"}}>×</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {/* Referências */}
            <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,overflow:"hidden"}}>
              <div style={{background:"#fffbeb",borderBottom:`1px solid ${C.border}`,padding:"10px 16px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <span style={{fontSize:11,fontWeight:700,color:"#92400e"}}>📖 Referências — {bibCache.length}</span>
                {saved.bib&&<span style={{fontSize:10,color:C.green,fontFamily:"monospace"}}>● salvo</span>}
                {bibCache.length>0&&<button onClick={()=>{navigator.clipboard?.writeText(bibCache.map(b=>b.texto).join("\n"));setCopiedBib("all");setTimeout(()=>setCopiedBib(null),2500);}} style={{padding:"3px 10px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",fontSize:10,fontFamily:"monospace",color:C.textSec}}>{copiedBib==="all"?"✅":"📋 Copiar todas"}</button>}
              </div>
              <div style={{padding:"12px"}}>
                <textarea value={bibInput} onChange={e=>setBibInput(e.target.value)} placeholder="Cole referência ABNT do JurBiblioteca..." style={{...inp,minHeight:70,resize:"vertical",lineHeight:1.6,fontSize:12}}/>
                <button onClick={addBib} disabled={!bibInput.trim()} style={{width:"100%",marginTop:8,padding:"7px",background:"#92400e",color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:12,fontFamily:"monospace",opacity:bibInput.trim()?1:.4}}>+ Adicionar</button>
              </div>
              <div style={{borderTop:`1px solid ${C.border}`,maxHeight:250,overflowY:"auto"}}>
                {bibCache.length===0?<div style={{padding:"20px",textAlign:"center",color:C.textTer,fontSize:12}}>Nenhuma referência</div>:bibCache.map((b,i)=>(
                  <div key={b.id} style={{padding:"8px 12px",borderBottom:i<bibCache.length-1?`1px solid ${C.border}`:"none",display:"flex",gap:8,alignItems:"flex-start"}}>
                    <span style={{fontSize:10,fontFamily:"monospace",color:C.textTer,flexShrink:0}}>{i+1}.</span>
                    <div style={{flex:1,fontSize:11,color:C.textSec,lineHeight:1.5,fontFamily:"monospace"}}>{b.texto}</div>
                    <div style={{display:"flex",gap:3,flexShrink:0}}>
                      <button onClick={()=>{navigator.clipboard?.writeText(b.texto);setCopiedBib(b.id);setTimeout(()=>setCopiedBib(null),2000);}} style={{padding:"2px 6px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:3,cursor:"pointer",fontSize:9,fontFamily:"monospace",color:C.textSec}}>{copiedBib===b.id?"✅":"📋"}</button>
                      <button onClick={()=>remBib(b.id)} style={{padding:"2px 6px",background:"transparent",border:`1px solid ${C.border}`,borderRadius:3,cursor:"pointer",fontSize:9,color:"#991b1b"}}>×</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Export */}
        {aba==="export"&&(
          <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,overflow:"hidden"}}>
            <div style={{background:"#f0ebe0",borderBottom:`1px solid ${C.border}`,padding:"10px 20px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <span style={{fontSize:11,fontWeight:700,color:C.nav}}>📄 Export completo da obra · {capsTexto.split(/\s+/).filter(Boolean).length.toLocaleString("pt-BR")} palavras</span>
              <button onClick={exportarObra} disabled={exportStatus==="loading"||!capsTexto.trim()} style={{padding:"7px 20px",background:exportStatus==="done"?C.green:C.nav,color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:12,fontFamily:"monospace",fontWeight:700,opacity:!capsTexto.trim()?.4:1}}>
                {exportStatus==="loading"?"⏳ gerando...":exportStatus==="done"?"✅ baixado!":"⬇ Exportar .docx"}
              </button>
            </div>
            <div style={{padding:"16px 20px"}}>
              <div style={{marginBottom:10,padding:"10px 14px",background:"#f7f3ec",borderRadius:6,borderLeft:`3px solid ${C.gold}`,fontSize:12,color:C.textSec,lineHeight:1.7}}>
                Cole aqui todos os capítulos gerados pelo <strong>JurObra</strong> em ordem. O Hub gera um único .docx com capa + sumário + corpo + footnotes.
              </div>
              <textarea value={capsTexto} onChange={e=>salvarCaps(e.target.value)} placeholder="Cole os capítulos em ordem aqui..." style={{...inp,minHeight:340,resize:"vertical",lineHeight:1.75,fontSize:12,fontFamily:"Georgia,serif"}}/>
            </div>
          </div>
        )}
      </div>

      {/* Modal Projeto */}
      {editProj&&(
        <div style={{position:"fixed",inset:0,background:"rgba(5,10,25,.87)",zIndex:4000,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
          <div style={{background:"white",borderRadius:10,width:"100%",maxWidth:600,maxHeight:"90vh",display:"flex",flexDirection:"column",boxShadow:"0 40px 100px rgba(0,0,0,.6)"}}>
            <div style={{background:`linear-gradient(90deg,#0f1a33,${C.nav})`,padding:"14px 22px",borderRadius:"10px 10px 0 0",display:"flex",alignItems:"center",gap:12}}>
              <span style={{color:"white",fontWeight:700,fontSize:15,fontFamily:"Georgia,serif",flex:1}}>⚙️ Configurar Projeto</span>
              <button onClick={()=>setEditProj(false)} style={{background:"rgba(255,255,255,.12)",border:"1px solid rgba(255,255,255,.2)",color:"white",width:32,height:32,borderRadius:5,cursor:"pointer",fontSize:18}}>×</button>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"14px 24px"}}>
              {[["📖 Nome da obra","nome","Ex: Teoria Geral do Processo"],["🏛 Área","area","Ex: Direito Processual Civil"],["✍️ Autores","autores","Ex: Ada Pellegrini Grinover"]].map(([lbl,field,ph])=>(
                <div key={field} style={{marginBottom:12}}>
                  <label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:4}}>{lbl}</label>
                  <input value={projEdit[field]||""} onChange={e=>setProjEdit(p=>({...p,[field]:e.target.value}))} placeholder={ph} style={inp}/>
                </div>
              ))}
              <div style={{marginBottom:12}}>
                <label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:4}}>✅ Capítulos concluídos <span style={{fontWeight:400,color:C.textTer}}>(um por linha)</span></label>
                <textarea value={(projEdit.capsOk||[]).join("\n")} onChange={e=>setProjEdit(p=>({...p,capsOk:e.target.value.split("\n").map(l=>l.trim()).filter(Boolean)}))} style={{...inp,minHeight:70,resize:"vertical",lineHeight:1.6,fontSize:12}} placeholder="Cap. 1 — Fundamentos&#10;Cap. 2 — Princípios"/>
              </div>
              <div style={{marginBottom:12}}>
                <label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:4}}>⏳ Próximos <span style={{fontWeight:400,color:C.textTer}}>número|título</span></label>
                <textarea value={(projEdit.capsProx||[]).map(c=>`${c.num}|${c.titulo}`).join("\n")} onChange={e=>setProjEdit(p=>({...p,capsProx:e.target.value.split("\n").map(l=>{const[n,...r]=l.trim().split("|");return n&&r.length?{num:n.trim(),titulo:r.join("|").trim()}:null;}).filter(Boolean)}))} style={{...inp,minHeight:90,resize:"vertical",lineHeight:1.6,fontSize:12}} placeholder="3|Jurisdição e Ação&#10;4|Competência"/>
              </div>
            </div>
            <div style={{padding:"12px 24px",background:"#f7f3ec",borderTop:`1px solid ${C.border}`,borderRadius:"0 0 10px 10px",display:"flex",justifyContent:"flex-end",gap:8}}>
              <button onClick={()=>setEditProj(false)} style={{padding:"8px 18px",background:"white",border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif"}}>Cancelar</button>
              <button onClick={()=>salvarProj(projEdit)} style={{padding:"8px 28px",background:C.nav,color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>💾 Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
