"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import mammoth from "mammoth";
import RichText from "../shared/RichText";
import { storageGet, storageSet } from "../../lib/storage";
import { emptyP, wPara, wPFN, wFN, parseNN, SC, downloadDocx } from "../../lib/docx";

const K_PROJ="jura-obra-project-v1",K_JUR="jura-jur-cache",K_BIB="jura-bib-cache";
const PROJ_DEF={nome:"",area:"",autores:"",capsOk:[],capsProx:[]};
const TIPO_OBRA=[{v:"Capítulo de livro jurídico / Tratado acadêmico",l:"Tratado / Livro"},{v:"Artigo científico jurídico (Qualis/ABNT)",l:"Artigo Científico"},{v:"Dissertação ou tese de doutorado",l:"Dissertação / Tese"},{v:"Apostila jurídica",l:"Apostila"}];
const NIVEIS=[{v:"Doutorado e tratados acadêmicos de referência",l:"Doutorado / Tratado"},{v:"Operadores do Direito (juízes, advogados, promotores)",l:"Operadores do Direito"},{v:"Mestrado e pós-graduação stricto sensu",l:"Mestrado / Pós-Grad."},{v:"Graduação avançada",l:"Graduação Avançada"}];
const ACOES=[{ic:"📝",l:"Capítulo completo",p:"Pesquise jurisprudência e doutrina atualizada e desenvolva o capítulo COMPLETO com cabeçalho (Capítulo N, TÍTULO, EMENTA_CAP), seções **negrito**, parágrafos com recuo, mínimo 30 notas ¹²³ e ② NOTAS DE RODAPÉ. Tema: "},{ic:"📄",l:"Introdução da obra",p:"Redija a Introdução completa com apresentação, justificativa, delimitação, metodologia e estrutura dos capítulos, para: "},{ic:"📚",l:"Referências doutrinárias",p:"Pesquise e cite doutrina nacional e estrangeira (2020–2025 + clássicos fundantes) sobre: "},{ic:"🔎",l:"Jurisprudência STF/STJ",p:"Pesquise jurisprudência STF e STJ (2020–2025) com número, relator, turma e data sobre: "},{ic:"▶️",l:"Continuar texto",p:"Continue o texto EXATAMENTE de onde parou, sem repetir nenhuma linha já escrita:\n\n"},{ic:"📊",l:"Avaliação técnica",p:"Avalie com rubrica de 8 critérios (rigor, clareza, coesão, progressão, fontes, ABNT, estilo, originalidade), nota 0–10:\n\n"},{ic:"✏️",l:"Editar e aprimorar",p:"Edite preservando a voz e o posicionamento do autor:\n\n"},{ic:"🔍",l:"Revisão completa",p:"Revisão técnica: gramática, terminologia jurídica, ABNT e consistência:\n\n"}];

function buildSystem(tipo,nivel,proj,jurCache,bibCache){
  const jurStr=jurCache.length>0?`\nCITAÇÕES DO BANCO:\n${jurCache.map((j,i)=>`[JUR-${i+1}] ${j.texto}`).join("\n")}`:"";
  const bibStr=bibCache.length>0?`\nREFERÊNCIAS DO BANCO:\n${bibCache.map((b,i)=>`[BIB-${i+1}] ${b.texto}`).join("\n")}`:"";
  return `Você é JurObra Excellence v2 — redator jurídico de máximo padrão acadêmico com busca web em tempo real.\n\nPROJETO: "${proj.nome||"Sem título"}"\nÁrea: ${proj.area||"Direito"} | Nível: ${nivel} | Tipo: ${tipo}\nCapítulos concluídos: ${proj.capsOk.join(", ")||"nenhum"}\nPróximos: ${proj.capsProx.map(c=>`Cap.${c.num} (${c.titulo})`).join("; ")||"a definir"}${jurStr}${bibStr}\n\nPADRÃO MANUAL JURÍDICO ACADÊMICO CLÁSSICO:\n⓪ CABEÇALHO: Capítulo [N] / TÍTULO EM CAIXA ALTA / EMENTA_CAP: subtemas. / ---\n① SEÇÕES: **negrito**, alinhado à esquerda, sem numeração arábica\n② CORPO: recuo de 1ª linha · obras em *itálico* · voz impessoal\n③ NOTAS: superscript ¹²³ colado à palavra · mínimo 30 por capítulo\n④ JURISPRUDÊNCIA: inline · somente STF/STJ/TRFs 2020–2025 confirmada\n⑤ SEÇÃO FINAL: ② NOTAS DE RODAPÉ\n\n✗ NUNCA invente número de processo, relator, data, autor ou obra\n✓ NUNCA corte o texto — entregue o capítulo COMPLETO`;
}

export default function JurObra() {
  const [projeto,setProjeto]=useState(PROJ_DEF);
  const [tipo,setTipo]=useState(TIPO_OBRA[0].v);
  const [nivel,setNivel]=useState(NIVEIS[0].v);
  const [msgs,setMsgs]=useState([]);
  const [input,setInput]=useState("");
  const [loading,setLoading]=useState(false);
  const [modal,setModal]=useState(null);
  const [exportStatus,setExportStatus]=useState("idle");
  const [storageOk,setStorageOk]=useState(false);
  const [sidebarOpen,setSidebarOpen]=useState(true);
  const [jurCache,setJurCache]=useState([]);
  const [bibCache,setBibCache]=useState([]);
  const [doc,setDoc]=useState(null);
  const [showUpload,setShowUpload]=useState(false);
  const [uploadErr,setUploadErr]=useState("");
  const [hubSec,setHubSec]=useState("jur");
  const [inserido,setInserido]=useState(null);
  const fileInputRef=useRef(null);
  const bottomRef=useRef(null);
  const taRef=useRef(null);

  useEffect(()=>{
    (async()=>{
      const[p,j,b]=await Promise.all([storageGet(K_PROJ),storageGet(K_JUR),storageGet(K_BIB)]);
      if(p){setProjeto(p);setStorageOk(true);}
      if(j)setJurCache(Array.isArray(j)?j:[]);
      if(b)setBibCache(Array.isArray(b)?b:[]);
    })();
  },[]);

  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,loading]);
  useEffect(()=>{if(taRef.current){taRef.current.style.height="auto";taRef.current.style.height=Math.min(taRef.current.scrollHeight,160)+"px";}},[input]);

  const salvarProjeto=async(p)=>{setProjeto(p);setModal(null);await storageSet(K_PROJ,p);setStorageOk(true);};

  const handleFile=async(file)=>{
    if(!file)return;
    setUploadErr("");
    try{
      const ext=file.name.split(".").pop().toLowerCase();
      if(ext==="pdf"){
        const reader=new FileReader();
        reader.onload=e=>{setDoc({tipo:"pdf",base64:e.target.result.split(",")[1],nome:file.name});setShowUpload(false);};
        reader.readAsDataURL(file);
      } else if(["docx","doc"].includes(ext)){
        const reader=new FileReader();
        reader.onload=async e=>{const r=await mammoth.extractRawText({arrayBuffer:e.target.result});setDoc({tipo:"docx",texto:r.value,nome:file.name});setShowUpload(false);};
        reader.readAsArrayBuffer(file);
      } else setUploadErr("Use PDF ou DOCX.");
    }catch(e){setUploadErr(e.message);}
  };

  const inserirNoBanco=(txt,idx)=>{setInput(prev=>prev?prev+"\n\n"+txt:txt);setInserido(idx);setTimeout(()=>setInserido(null),2000);taRef.current?.focus();};

  const dispararCapitulo=(cap)=>{
    const jurStr=jurCache.length>0?`\nUse as citações: ${jurCache.map(j=>j.texto).join(" | ")}`:"";
    const bibStr=bibCache.length>0?`\nUse as referências: ${bibCache.map(b=>b.texto).join(" | ")}`:"";
    enviar(`Pesquise jurisprudência e doutrina e desenvolva o CAPÍTULO ${cap.num} COMPLETO com padrão manual clássico. Cabeçalho, seções em **negrito**, parágrafos com recuo, mínimo 30 notas ¹²³ e ② NOTAS DE RODAPÉ ao final.${jurStr}${bibStr}\n\nCapítulo: ${cap.num}|${cap.titulo}`);
  };

  const enviar=useCallback(async(texto)=>{
    const prompt=texto||input.trim();
    if(!prompt&&!doc)return;
    if(loading)return;
    setInput("");
    let msgContent=prompt;
    let apiContent=prompt;
    if(doc){
      if(doc.tipo==="pdf"){apiContent=[{type:"document",source:{type:"base64",media_type:"application/pdf",data:doc.base64}},{type:"text",text:prompt||"Analise este documento como obra de referência."}];}
      else{apiContent=[{type:"text",text:`DOCUMENTO (${doc.nome}):\n\n${doc.texto.slice(0,30000)}\n\n---\n\n${prompt||"Analise este documento."}`}];}
    }
    const novasMsgs=[...msgs,{role:"user",content:msgContent,docNome:doc?.nome,_apiContent:apiContent}];
    setMsgs(novasMsgs);setLoading(true);
    try{
      const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:buildSystem(tipo,nivel,projeto,jurCache,bibCache),messages:novasMsgs.map(m=>({role:m.role,content:m._apiContent||m.content})),tools:[{type:"web_search_20250305",name:"web_search"}]})});
      const data=await resp.json();
      const txt=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim();
      setMsgs(prev=>[...prev,{role:"assistant",content:txt||"Sem resposta."}]);
      setDoc(null);
    }catch(e){setMsgs(prev=>[...prev,{role:"assistant",content:"❌ Erro de conexão."}]);}
    finally{setLoading(false);}
  },[msgs,input,loading,tipo,nivel,projeto,jurCache,bibCache,doc]);

  const handleExport=async()=>{
    const conteudo=msgs.filter(m=>m.role==="assistant").map(m=>m.content).join("\n\n");
    if(!conteudo.trim())return;
    setExportStatus("loading");
    try{
      const lines=conteudo.split("\n");const noteIdx=lines.findIndex(l=>/^②?\s*NOTAS?\s*DE\s*RODAP/i.test(l.trim()));
      const bodyLines=noteIdx>-1?lines.slice(0,noteIdx):lines;const fm={};
      const paras=[emptyP(),emptyP(),emptyP()];
      if(projeto.area)paras.push(wPara([{text:projeto.area,bold:false,italic:true,sup:false}],{center:true,sizePt:11,spaceAfter:60,lineVal:240}));
      paras.push(wPara([{text:projeto.nome||"Obra Jurídica",bold:true,italic:false,sup:false}],{center:true,sizePt:22,spaceBefore:60,spaceAfter:160,lineVal:280}));
      if(projeto.autores)paras.push(wPara([{text:projeto.autores,bold:false,italic:false,sup:false}],{center:true,sizePt:11,spaceAfter:40,lineVal:240}));
      paras.push(emptyP(),emptyP());
      const allCaps=[...projeto.capsOk.map((c,i)=>({label:c,ok:true})),...projeto.capsProx.map(c=>({label:`Cap. ${c.num} — ${c.titulo}`,ok:false}))];
      if(allCaps.length>0){
        paras.push(wPara([{text:"SUMÁRIO",bold:true,italic:false,sup:false}],{center:true,sizePt:14,spaceBefore:80,spaceAfter:200,lineVal:240}));
        for(const c of allCaps)paras.push(wPara([{text:(c.ok?"✓  ":"")+c.label,bold:false,italic:false,sup:false}],{align:"left",sizePt:11,spaceBefore:60,spaceAfter:40,lineVal:240}));
        paras.push(emptyP(),`<w:p><w:pPr><w:pageBreakBefore/></w:pPr></w:p>`);
      }
      for(const line of bodyLines){
        const raw=line.trim();if(!raw){paras.push(emptyP());continue;}
        if(/^-{3,}$/.test(raw)){paras.push(`<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr><w:spacing w:before="120" w:after="120"/></w:pPr></w:p>`);continue;}
        if(/^Cap[íi]tulo\s+[IVXLCDM\d]+$/i.test(raw)){paras.push(wPara([{text:raw,bold:false,italic:false,sup:false}],{center:true,sizePt:12,spaceAfter:120,lineVal:240}));continue;}
        if(raw===raw.toUpperCase()&&/[A-ZÁÉÍÓÚ]{4,}/.test(raw)&&raw.length>4&&raw.length<120&&!/^\d/.test(raw)&&!/^[①②③④⑤]/.test(raw)){paras.push(wPara([{text:raw,bold:true,italic:false,sup:false}],{center:true,sizePt:14,spaceAfter:360,lineVal:240}));continue;}
        if(/^EMENTA_CAP:/i.test(raw)){paras.push(wPara([{text:raw.replace(/^EMENTA_CAP:\s*/i,""),bold:false,italic:true,sup:false}],{align:"both",sizePt:10,spaceAfter:0,lineVal:240,indentLeft:1440,indentRight:1440}));continue;}
        if(/^\*\*[^*]+\*\*$/.test(raw)){paras.push(wPara([{text:raw.replace(/\*\*/g,""),bold:true,italic:false,sup:false}],{align:"left",sizePt:12,spaceBefore:360,spaceAfter:120,lineVal:276}));continue;}
        if(/^>\s*/.test(raw)){paras.push(wPFN(raw.replace(/^>\s*/,""),{align:"both",sizePt:9,spaceBefore:80,spaceAfter:80,lineVal:240,indentLeft:709,indentRight:709},fm));continue;}
        const rc=raw.replace(/\*\*/g,"").trim();
        if(/^[①②③④⑤]/.test(rc)||/^NOTAS?\s*DE\s*RODAP/i.test(rc))continue;
        if((SC.includes(raw[0])||/^\d{1,2}[.\)]\s/.test(raw))&&raw.length<400){const p=parseNN(raw);if(p&&p.text.length>10)continue;}
        paras.push(wPFN(raw,{align:"both",sizePt:12,indent:709,spaceBefore:0,spaceAfter:60,lineVal:276},fm));
      }
      const fnE=Object.entries(fm).sort((a,b)=>Number(a[0])-Number(b[0]));
      const capLine=bodyLines.find(l=>/^CAPÍTULO\s+\d+/i.test(l.trim()))||"";
      const titLine=bodyLines.find((l,i)=>i>0&&l.trim()&&l.trim()===l.trim().toUpperCase()&&/[A-ZÁÉÍÓÚ]{4,}/.test(l.trim()))||"";
      const hTxt=([capLine.trim(),titLine.trim()].filter(Boolean).join(" — ")||projeto.nome||"Edição Acadêmica").slice(0,80);
      const slug=(projeto.nome||"JurObra").replace(/[^a-zA-Z0-9]/g,"_").slice(0,30);
      downloadDocx(paras,hTxt,fnE,slug+"_"+new Date().toISOString().slice(0,10)+".docx");
      setExportStatus("done");setTimeout(()=>setExportStatus("idle"),6000);
    }catch(e){console.error(e);setExportStatus("error");setTimeout(()=>setExportStatus("idle"),4000);}
  };

  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",red:"#8b1a1a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999"};
  const hasContent=msgs.some(m=>m.role==="assistant");
  const prog=projeto.capsOk.length,total=projeto.capsOk.length+projeto.capsProx.length;

  return(
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      {/* Top bar */}
      <div style={{background:C.nav,padding:"0 18px",display:"flex",alignItems:"center",gap:10,height:48,flexShrink:0,borderBottom:"1px solid #0a1020"}}>
        <button onClick={()=>setSidebarOpen(v=>!v)} style={{background:"none",border:"none",color:"rgba(255,255,255,.5)",cursor:"pointer",fontSize:16}}>☰</button>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JUROBRA</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v2</span>
        {projeto.nome&&<><span style={{fontSize:12,color:"rgba(255,255,255,.6)"}}>📖 {projeto.nome.slice(0,40)}</span>{storageOk&&<span style={{fontSize:9,color:"#4ade80",fontFamily:"monospace"}}>● salvo</span>}</>}
        {(jurCache.length>0||bibCache.length>0)&&<span style={{fontSize:9,color:"#60a5fa",fontFamily:"monospace"}}>🔗 {jurCache.length} cit. · {bibCache.length} ref.</span>}
        <div style={{marginLeft:"auto",display:"flex",gap:8}}>
          {hasContent&&<button onClick={handleExport} disabled={exportStatus==="loading"} style={{padding:"5px 14px",background:exportStatus==="done"?"#166534":C.red,color:"white",border:"none",borderRadius:3,fontSize:11,fontFamily:"monospace",cursor:"pointer"}}>{exportStatus==="loading"?"⏳...":exportStatus==="done"?"✅ gerado!":"⬇ .docx"}</button>}
          <button onClick={()=>setModal("sumario")} style={{padding:"5px 12px",background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.6)",border:"1px solid rgba(255,255,255,.12)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>🗂️ Sumário</button>
          <button onClick={()=>setModal("projeto")} style={{padding:"5px 12px",background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.6)",border:"1px solid rgba(255,255,255,.12)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>⚙️ Projeto</button>
          {msgs.length>0&&<button onClick={()=>{if(window.confirm("Limpar?"))setMsgs([]);}} style={{padding:"5px 10px",background:"transparent",color:"rgba(255,255,255,.25)",border:"1px solid rgba(255,255,255,.08)",borderRadius:3,fontSize:10,fontFamily:"monospace",cursor:"pointer"}}>limpar</button>}
        </div>
      </div>
      <div style={{flex:1,display:"flex",overflow:"hidden"}}>
        {/* Sidebar */}
        {sidebarOpen&&(
          <div style={{width:240,background:C.white,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
            <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Tipo de obra</div>
              <select value={tipo} onChange={e=>setTipo(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:11,background:C.bg,outline:"none",marginBottom:8}}>
                {TIPO_OBRA.map(t=><option key={t.v} value={t.v}>{t.l}</option>)}
              </select>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>Nível</div>
              <select value={nivel} onChange={e=>setNivel(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:11,background:C.bg,outline:"none"}}>
                {NIVEIS.map(n=><option key={n.v} value={n.v}>{n.l}</option>)}
              </select>
            </div>
            {(projeto.capsOk.length>0||projeto.capsProx.length>0)&&(
              <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}><span style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase"}}>Progresso</span><span style={{fontSize:11,fontWeight:700,color:C.gold,fontFamily:"monospace"}}>{prog}/{total}</span></div>
                <div style={{height:4,background:"#ede8df",borderRadius:2,marginBottom:8,overflow:"hidden"}}><div style={{height:"100%",background:C.gold,borderRadius:2,width:total>0?`${(prog/total)*100}%`:"0%",transition:"width .4s"}}/></div>
                {projeto.capsOk.map((c,i)=><div key={i} style={{fontSize:10,color:"#166534",fontFamily:"monospace",padding:"1px 0"}}>✓ {c.slice(0,36)}</div>)}
                {projeto.capsProx.length>0&&<div style={{marginTop:6}}><div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,marginBottom:4,textTransform:"uppercase"}}>Gerar agora</div>{projeto.capsProx.map((c,i)=><button key={i} onClick={()=>dispararCapitulo(c)} style={{display:"flex",alignItems:"flex-start",gap:6,width:"100%",padding:"5px 7px",marginBottom:3,border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",textAlign:"left",background:"transparent",color:C.textSec,fontSize:10,fontFamily:"Georgia,serif",lineHeight:1.4}} onMouseOver={e=>{e.currentTarget.style.background=`${C.gold}12`;e.currentTarget.style.borderColor=`${C.gold}60`;}} onMouseOut={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.borderColor=C.border;}}><span style={{color:C.gold,flexShrink:0,fontWeight:700}}>→</span><span>Cap. {c.num} — {c.titulo.slice(0,32)}</span></button>)}</div>}
              </div>
            )}
            {(jurCache.length>0||bibCache.length>0)&&(
              <div style={{borderBottom:`1px solid ${C.border}`}}>
                <div style={{padding:"6px 14px 0",display:"flex",gap:0}}>
                  {[["jur",`⚖️ ${jurCache.length}`,"#0369a1"],["bib",`📖 ${bibCache.length}`,"#c49a2a"]].map(([id,label,cor])=>(
                    <button key={id} onClick={()=>setHubSec(id)} style={{flex:1,padding:"5px 0",border:"none",background:hubSec===id?C.white:"transparent",cursor:"pointer",fontSize:10,fontFamily:"monospace",color:hubSec===id?cor:C.textTer,fontWeight:hubSec===id?700:400,borderBottom:hubSec===id?`2px solid ${cor}`:"2px solid transparent",transition:"all .15s"}}>{label}</button>
                  ))}
                </div>
                <div style={{maxHeight:120,overflowY:"auto",padding:"6px 8px"}}>
                  {(hubSec==="jur"?jurCache:bibCache).map((item,i)=>(
                    <div key={item.id} style={{display:"flex",gap:4,alignItems:"flex-start",marginBottom:3}}>
                      <div style={{flex:1,fontSize:10,color:C.textSec,lineHeight:1.5,overflow:"hidden"}}>{item.texto.slice(0,60)}...</div>
                      <button onClick={()=>inserirNoBanco(item.texto,`${hubSec}-${i}`)} style={{padding:"2px 5px",background:inserido===`${hubSec}-${i}`?"#f0fdf4":"transparent",border:`1px solid ${inserido===`${hubSec}-${i}`?"#86efac":C.border}`,borderRadius:3,cursor:"pointer",fontSize:9,fontFamily:"monospace",color:inserido===`${hubSec}-${i}`?"#166534":C.textTer,flexShrink:0}}>{inserido===`${hubSec}-${i}`?"✓":"→"}</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div style={{flex:1,overflowY:"auto",padding:"10px 14px"}}>
              <div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:6}}>Ações rápidas</div>
              {ACOES.map((a,i)=>(
                <button key={i} onClick={()=>enviar(a.p)} style={{display:"flex",alignItems:"flex-start",gap:7,width:"100%",padding:"7px 9px",marginBottom:4,border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",textAlign:"left",background:"transparent",color:C.textSec,fontSize:11,fontFamily:"Georgia,serif",lineHeight:1.4,transition:"all .12s"}} onMouseOver={e=>{e.currentTarget.style.background=`${C.red}0e`;e.currentTarget.style.color=C.textPri;}} onMouseOut={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color=C.textSec;}}>
                  <span style={{flexShrink:0}}>{a.ic}</span><span>{a.l}</span>
                </button>
              ))}
            </div>
            <div style={{padding:"10px 14px",borderTop:`1px solid ${C.border}`,background:"#f7f3ec"}}>
              <button onClick={()=>setModal("projeto")} style={{width:"100%",padding:"8px",background:C.nav,color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",fontWeight:700}}>⚙️ {projeto.nome?"Editar Projeto":"Configurar Projeto"}</button>
            </div>
          </div>
        )}
        {/* Chat */}
        <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          {showUpload&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"14px 20px",flexShrink:0}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:12,fontWeight:500}}>Carregar documento de referência (PDF/DOCX)</span><button onClick={()=>setShowUpload(false)} style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:C.textTer}}>×</button></div>
              <div onDrop={e=>{e.preventDefault();handleFile(e.dataTransfer.files[0]);}} onDragOver={e=>e.preventDefault()} onClick={()=>fileInputRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:8,padding:"16px",textAlign:"center",cursor:"pointer",background:"#faf8f4"}}><div style={{fontSize:24,marginBottom:4}}>📄</div><div style={{fontSize:12,color:C.textSec}}>Arraste PDF ou DOCX aqui · ou clique</div></div>
              <input ref={fileInputRef} type="file" accept=".pdf,.docx,.doc" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])}/>
              {uploadErr&&<div style={{marginTop:6,fontSize:11,color:"#991b1b",fontFamily:"monospace"}}>❌ {uploadErr}</div>}
            </div>
          )}
          {!showUpload&&doc&&(
            <div style={{background:C.white,borderBottom:`1px solid ${C.border}`,padding:"7px 18px",flexShrink:0}}>
              <span style={{display:"inline-flex",alignItems:"center",gap:6,padding:"3px 10px",background:`${C.red}12`,border:`1px solid ${C.red}30`,borderRadius:12,fontSize:11,fontFamily:"monospace",color:C.red}}>
                {doc.tipo==="pdf"?"📕":"📝"} {doc.nome.slice(0,28)}<button onClick={()=>setDoc(null)} style={{background:"none",border:"none",cursor:"pointer",color:"inherit",fontSize:12,padding:"0 0 0 4px"}}>×</button>
              </span>
            </div>
          )}
          <div style={{flex:1,overflowY:"auto",padding:"20px 24px"}}>
            {msgs.length===0&&(
              <div style={{maxWidth:560,margin:"40px auto 0",textAlign:"center"}}>
                <div style={{fontSize:36,marginBottom:10}}>📚</div>
                <div style={{fontSize:18,fontWeight:700,marginBottom:6}}>JurObra v2</div>
                <div style={{fontSize:13,color:C.textSec,lineHeight:1.7,marginBottom:16}}>{projeto.nome?`📖 ${projeto.nome}`:"Configure o projeto para começar"}{projeto.area&&<><br/><span style={{fontSize:12}}>{projeto.area}</span></>}</div>
                {!projeto.nome&&<button onClick={()=>setModal("projeto")} style={{padding:"10px 24px",background:C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>⚙️ Configurar Projeto</button>}
                {projeto.nome&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,textAlign:"left"}}>{ACOES.slice(0,4).map((a,i)=><button key={i} onClick={()=>enviar(a.p)} style={{padding:"10px 12px",border:`1px solid ${C.border}`,borderRadius:6,cursor:"pointer",background:C.white,textAlign:"left",fontSize:12,color:C.textSec,fontFamily:"Georgia,serif",lineHeight:1.4}} onMouseOver={e=>{e.currentTarget.style.borderColor=C.gold;}} onMouseOut={e=>{e.currentTarget.style.borderColor=C.border;}}>{a.ic} {a.l}</button>)}</div>}
              </div>
            )}
            {msgs.map((m,i)=>(
              <div key={i} style={{marginBottom:20,display:"flex",gap:12,justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                {m.role==="assistant"&&<div style={{width:28,height:28,background:C.red,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0,marginTop:2}}>📚</div>}
                <div style={{maxWidth:"82%"}}>
                  {m.docNome&&<div style={{display:"flex",gap:6,marginBottom:4,justifyContent:"flex-end"}}><span style={{fontSize:10,fontFamily:"monospace",padding:"2px 8px",background:`${C.red}15`,border:`1px solid ${C.red}30`,borderRadius:10,color:C.red}}>📄 {m.docNome?.slice(0,20)}</span></div>}
                  <div style={{padding:"12px 16px",borderRadius:m.role==="user"?"16px 4px 16px 16px":"4px 16px 16px 16px",background:m.role==="user"?C.nav:C.white,color:m.role==="user"?"white":C.textPri,border:m.role==="assistant"?`1px solid ${C.border}`:"none",fontSize:13,lineHeight:1.75}}>
                    {m.role==="assistant"?<RichText content={m.content}/>:<span style={{fontFamily:"Georgia,serif",fontSize:13}}>{m.content}</span>}
                  </div>
                </div>
              </div>
            ))}
            {loading&&<div style={{display:"flex",gap:12,marginBottom:20}}><div style={{width:28,height:28,background:C.red,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>📚</div><div style={{padding:"12px 16px",background:C.white,border:`1px solid ${C.border}`,borderRadius:"4px 16px 16px 16px",display:"flex",gap:6,alignItems:"center"}}>{[0,1,2].map(j=><div key={j} style={{width:7,height:7,borderRadius:"50%",background:C.red,opacity:.5,animation:`bounce 1.2s ease-in-out ${j*.2}s infinite`}}/>)}</div></div>}
            <div ref={bottomRef}/>
          </div>
          <div style={{borderTop:`1px solid ${C.border}`,background:C.white,padding:"12px 18px"}}>
            <div style={{display:"flex",gap:8,alignItems:"flex-end",maxWidth:900,margin:"0 auto"}}>
              <button onClick={()=>setShowUpload(v=>!v)} style={{width:40,height:40,display:"flex",alignItems:"center",justifyContent:"center",border:`1px solid ${doc?C.red:C.border}`,borderRadius:8,cursor:"pointer",background:doc?`${C.red}12`:C.bg,color:doc?C.red:C.textTer,fontSize:18,flexShrink:0}}>📎</button>
              <textarea ref={taRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();enviar();}}} placeholder="Descreva o capítulo ou tema... (Enter para enviar)" rows={1} style={{flex:1,padding:"10px 14px",border:`1px solid ${C.border}`,borderRadius:8,fontFamily:"Georgia,serif",fontSize:13,resize:"none",outline:"none",lineHeight:1.6,overflow:"hidden",background:C.bg,color:C.textPri}} onFocus={e=>e.target.style.borderColor=C.gold} onBlur={e=>e.target.style.borderColor=C.border}/>
              <button onClick={()=>enviar()} disabled={loading||(!input.trim()&&!doc)} style={{padding:"10px 18px",background:loading||(!input.trim()&&!doc)?"#ccc":"#8b1a1a",color:"white",border:"none",borderRadius:8,cursor:loading||(!input.trim()&&!doc)?"not-allowed":"pointer",fontSize:16,flexShrink:0,height:40}}>↑</button>
            </div>
          </div>
        </div>
      </div>
      {/* Modais simplificados */}
      {modal==="projeto"&&(
        <div style={{position:"fixed",inset:0,background:"rgba(5,10,25,.87)",zIndex:4000,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
          <div style={{background:"white",borderRadius:10,width:"100%",maxWidth:600,maxHeight:"90vh",display:"flex",flexDirection:"column",boxShadow:"0 40px 100px rgba(0,0,0,.6)"}}>
            <div style={{background:`linear-gradient(90deg,#0f1a33,${C.nav})`,padding:"14px 22px",borderRadius:"10px 10px 0 0",display:"flex",alignItems:"center",gap:12}}><span style={{color:"white",fontWeight:700,fontSize:15,fontFamily:"Georgia,serif",flex:1}}>⚙️ Configurar Projeto</span><button onClick={()=>setModal(null)} style={{background:"rgba(255,255,255,.12)",border:"1px solid rgba(255,255,255,.2)",color:"white",width:32,height:32,borderRadius:5,cursor:"pointer",fontSize:18}}>×</button></div>
            <ModalProjetoContent projeto={projeto} onSave={salvarProjeto} onClose={()=>setModal(null)}/>
          </div>
        </div>
      )}
      {modal==="sumario"&&(
        <div style={{position:"fixed",inset:0,background:"rgba(5,10,25,.87)",zIndex:4000,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
          <div style={{background:"white",borderRadius:10,width:"100%",maxWidth:680,maxHeight:"90vh",display:"flex",flexDirection:"column",boxShadow:"0 40px 100px rgba(0,0,0,.6)"}}>
            <div style={{background:`linear-gradient(90deg,#0f1a33,${C.nav})`,padding:"14px 22px",borderRadius:"10px 10px 0 0",display:"flex",alignItems:"center",gap:12}}><span style={{color:"white",fontWeight:700,fontSize:15,fontFamily:"Georgia,serif",flex:1}}>🗂️ Gerador de Sumário</span><button onClick={()=>setModal(null)} style={{background:"rgba(255,255,255,.12)",border:"1px solid rgba(255,255,255,.2)",color:"white",width:32,height:32,borderRadius:5,cursor:"pointer",fontSize:18}}>×</button></div>
            <ModalSumarioContent projeto={projeto} onIntegrar={p=>{salvarProjeto(p);setModal(null);}} onClose={()=>setModal(null)}/>
          </div>
        </div>
      )}
    </div>
  );
}

function ModalProjetoContent({projeto,onSave,onClose}){
  const[v,setV]=useState({...projeto,capsOkTxt:projeto.capsOk.join("\n"),capsProxTxt:projeto.capsProx.map(c=>`${c.num}|${c.titulo}`).join("\n")});
  const inp={width:"100%",padding:"8px 12px",border:"1px solid #d4cfc6",borderRadius:4,fontFamily:"Georgia,serif",fontSize:13,outline:"none",boxSizing:"border-box"};
  const salvar=()=>{const capsOk=v.capsOkTxt.split("\n").map(l=>l.trim()).filter(Boolean);const capsProx=v.capsProxTxt.split("\n").map(l=>{const[n,...r]=l.trim().split("|");return n&&r.length?{num:n.trim(),titulo:r.join("|").trim()}:null;}).filter(Boolean);onSave({nome:v.nome.trim()||"Novo Projeto",area:v.area.trim(),autores:v.autores.trim(),capsOk,capsProx});};
  return(<><div style={{flex:1,overflowY:"auto",padding:"12px 24px"}}>
    {[["📖 Nome","nome","Teoria Geral do Processo"],["🏛 Área","area","Direito Processual Civil"],["✍️ Autores","autores","Ada Pellegrini Grinover"]].map(([lbl,field,ph])=><div key={field} style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:3}}>{lbl}</label><input style={inp} value={v[field]||""} onChange={e=>setV(p=>({...p,[field]:e.target.value}))} placeholder={ph}/></div>)}
    <div style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:3}}>✅ Capítulos concluídos</label><textarea style={{...inp,minHeight:70,resize:"vertical",lineHeight:1.6,fontSize:12}} value={v.capsOkTxt} onChange={e=>setV(p=>({...p,capsOkTxt:e.target.value}))} placeholder="Cap. 1 — Fundamentos&#10;Cap. 2 — Princípios"/></div>
    <div><label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:3}}>⏳ Próximos (número|título)</label><textarea style={{...inp,minHeight:80,resize:"vertical",lineHeight:1.6,fontSize:12}} value={v.capsProxTxt} onChange={e=>setV(p=>({...p,capsProxTxt:e.target.value}))} placeholder="3|Jurisdição&#10;4|Competência"/></div>
  </div><div style={{padding:"12px 24px",background:"#f7f3ec",borderTop:"1px solid #d4cfc6",display:"flex",justifyContent:"flex-end",gap:8}}>
    <button onClick={onClose} style={{padding:"8px 18px",background:"white",border:"1px solid #d4cfc6",borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif"}}>Cancelar</button>
    <button onClick={salvar} style={{padding:"8px 28px",background:"#12192e",color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>💾 Salvar</button>
  </div></>);
}

function ModalSumarioContent({projeto,onIntegrar,onClose}){
  const[titulo,setTitulo]=useState(projeto.nome||"");const[desc,setDesc]=useState("");const[output,setOutput]=useState("");const[loading,setLoading]=useState(false);const[erro,setErro]=useState("");const[step,setStep]=useState("form");
  async function gerar(){if(!titulo&&!desc){setErro("Preencha o título ou a descrição.");return;}setErro("");setLoading(true);setOutput("");try{const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:8000,messages:[{role:"user",content:`Gere um SUMÁRIO COMPLETO para o tratado jurídico:\nTítulo: ${titulo||"Não informado"} | Área: ${projeto.area||"Direito"}\n${desc?"Descrição: "+desc:""}\nAo final:\n\`\`\`CAPITULOS\n1|Título do Capítulo 1\n2|Título do Capítulo 2\n\`\`\``}]})});const data=await resp.json();const text=data?.content?.[0]?.text||"";if(!text)throw new Error("Resposta vazia.");setOutput(text);setStep("result");}catch(e){setErro("Erro: "+(e.message||"verifique a conexão."));}setLoading(false);}
  function integrar(){const caps=[];const m=output.match(/```CAPITULOS\s*\n([\s\S]*?)```/i);if(m){for(const l of m[1].split("\n")){const x=l.trim().match(/^(\d+)\|(.+)/);if(x)caps.push({num:x[1],titulo:x[2].trim()});}}if(!caps.length){setErro("Não foi possível extrair automaticamente.");return;}onIntegrar({...projeto,nome:titulo||projeto.nome,capsProx:caps});}
  const inp={width:"100%",padding:"9px 12px",border:"1px solid #d4cfc6",borderRadius:4,fontFamily:"Georgia,serif",fontSize:13,outline:"none",boxSizing:"border-box"};
  return step==="form"?(<><div style={{flex:1,overflowY:"auto",padding:"16px 24px"}}>
    <div style={{marginBottom:14}}><label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:4}}>Título da obra</label><input value={titulo} onChange={e=>setTitulo(e.target.value)} placeholder="Ex: Títulos de Crédito no Direito Brasileiro" style={inp}/></div>
    <div style={{marginBottom:14}}><label style={{fontSize:11,fontWeight:700,display:"block",marginBottom:4}}>Descrição</label><textarea value={desc} onChange={e=>setDesc(e.target.value)} rows={3} placeholder="Escopo, público e abordagem da obra..." style={{...inp,resize:"vertical"}}/></div>
    {erro&&<div style={{padding:"8px 12px",background:"#fef2f2",border:"1px solid #fca5a5",borderRadius:4,fontSize:12,color:"#991b1b",marginBottom:12}}>{erro}</div>}
    <button onClick={gerar} disabled={loading} style={{width:"100%",padding:"11px",background:loading?"#aaa":"#1a2744",color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>{loading?"⏳ Gerando...":"🗂️ Gerar Sumário com IA"}</button>
  </div></>):(
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{flex:1,overflowY:"auto",padding:"12px 24px"}}><div style={{background:"#f7f3ec",border:"1px solid #d4cfc6",borderRadius:4,padding:"12px",fontSize:12,fontFamily:"monospace",lineHeight:1.7,whiteSpace:"pre-wrap"}}>{output}</div></div>
      {erro&&<div style={{padding:"8px 16px",background:"#fef2f2",fontSize:11,color:"#991b1b"}}>{erro}</div>}
      <div style={{padding:"12px 24px",background:"#f7f3ec",borderTop:"1px solid #d4cfc6",display:"flex",gap:8,justifyContent:"flex-end"}}>
        <button onClick={()=>{setStep("form");setOutput("");setErro("");}} style={{padding:"8px 18px",background:"white",border:"1px solid #d4cfc6",borderRadius:4,cursor:"pointer",fontSize:12}}>← Refazer</button>
        <button onClick={()=>navigator.clipboard?.writeText(output)} style={{padding:"8px 18px",background:"white",border:"1px solid #d4cfc6",borderRadius:4,cursor:"pointer",fontSize:12}}>📋 Copiar</button>
        <button onClick={integrar} style={{padding:"8px 24px",background:"#166534",color:"white",border:"none",borderRadius:4,cursor:"pointer",fontSize:13,fontFamily:"Georgia,serif",fontWeight:700}}>✅ Integrar</button>
      </div>
    </div>
  );
}
