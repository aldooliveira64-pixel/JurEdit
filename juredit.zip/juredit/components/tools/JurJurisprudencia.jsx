"use client";
import { useState, useCallback } from "react";

const K_JUR="jura-jur-cache";
async function jurCacheAddLocal(texto){try{const raw=localStorage.getItem(K_JUR);const a=raw?JSON.parse(raw):[];if(!Array.isArray(a)||a.some(x=>x.texto===texto))return;localStorage.setItem(K_JUR,JSON.stringify([...a,{id:Date.now(),texto,ts:new Date().toLocaleDateString("pt-BR")}]));}catch{}}

const SUMULAS=[
  {id:"stf-11",tribunal:"STF",tipo:"Súmula Vinculante",numero:"11",tema:"Uso de algemas",ementa:"Só é lícito o uso de algemas em casos de resistência e de fundado receio de fuga ou de perigo à integridade física própria ou alheia, por parte do preso ou de terceiros, justificada a excepcionalidade por escrito, sob pena de responsabilidade disciplinar, civil e penal do agente e de nulidade da prisão.",area:"Direito Penal / Processual Penal",tags:["algemas","prisão","nulidade"]},
  {id:"stf-37",tribunal:"STF",tipo:"Súmula Vinculante",numero:"37",tema:"Equiparação de vencimentos",ementa:"Não cabe ao Poder Judiciário, que não tem função legislativa, aumentar vencimentos de servidores públicos sob o fundamento de isonomia.",area:"Direito Administrativo",tags:["servidor","isonomia","vencimentos"]},
  {id:"stj-7",tribunal:"STJ",tipo:"Súmula",numero:"7",tema:"Reexame de provas",ementa:"A pretensão de simples reexame de prova não enseja recurso especial.",area:"Processo Civil",tags:["REsp","prova","admissibilidade"]},
  {id:"stj-83",tribunal:"STJ",tipo:"Súmula",numero:"83",tema:"Divergência jurisprudencial",ementa:"Não se conhece do recurso especial pela divergência, quando a orientação do Tribunal se firmou no mesmo sentido da decisão recorrida.",area:"Processo Civil",tags:["REsp","divergência"]},
  {id:"stj-297",tribunal:"STJ",tipo:"Súmula",numero:"297",tema:"CDC — contratos bancários",ementa:"O Código de Defesa do Consumidor é aplicável às instituições financeiras.",area:"Direito Bancário",tags:["CDC","banco","consumidor"]},
  {id:"stj-381",tribunal:"STJ",tipo:"Súmula",numero:"381",tema:"Contratos bancários — cláusulas abusivas de ofício",ementa:"Nos contratos bancários, é vedado ao julgador conhecer, de ofício, da abusividade das cláusulas.",area:"Direito Bancário",tags:["contrato bancário","cláusula abusiva","CDC"]},
  {id:"stj-382",tribunal:"STJ",tipo:"Súmula",numero:"382",tema:"Juros remuneratórios — abusividade",ementa:"A estipulação de juros remuneratórios superiores a 12% ao ano, por si só, não indica abusividade.",area:"Direito Bancário",tags:["juros","abusividade","contrato bancário"]},
  {id:"stj-479",tribunal:"STJ",tipo:"Súmula",numero:"479",tema:"Fraude bancária — responsabilidade objetiva",ementa:"As instituições financeiras respondem objetivamente pelos danos gerados por fortuito interno relativo a fraudes e delitos praticados por terceiros no âmbito de operações bancárias.",area:"Direito Bancário",tags:["responsabilidade objetiva","fraude","banco"]},
  {id:"stj-530",tribunal:"STJ",tipo:"Súmula",numero:"530",tema:"Juros — taxa média BACEN",ementa:"Nos contratos bancários, na impossibilidade de comprovar a taxa de juros efetivamente contratada, prevalece a taxa média de mercado divulgada pelo Bacen, salvo se a taxa cobrada for mais vantajosa para o devedor.",area:"Direito Bancário",tags:["juros","taxa média","BACEN"]},
  {id:"stj-539",tribunal:"STJ",tipo:"Súmula",numero:"539",tema:"Cumulação de danos",ementa:"É permitida a cumulação das indenizações de dano estético e dano moral.",area:"Direito Civil",tags:["dano moral","dano estético","cumulação"]},
  {id:"stj-603",tribunal:"STJ",tipo:"Súmula",numero:"603",tema:"Plano de saúde — internação",ementa:"É abusiva a cláusula contratual de plano de saúde que limita no tempo a internação hospitalar do segurado.",area:"Direito do Consumidor",tags:["plano de saúde","cláusula abusiva","internação"]},
  {id:"tst-333",tribunal:"TST",tipo:"Súmula",numero:"333",tema:"Recurso de revista",ementa:"Não ensejam recurso de revista decisões superadas por iterativa, notória e atual jurisprudência do Tribunal Superior do Trabalho.",area:"Direito do Trabalho",tags:["recurso de revista","TST"]},
  {id:"tst-437",tribunal:"TST",tipo:"Súmula",numero:"437",tema:"Intervalo intrajornada",ementa:"A não-concessão ou a concessão parcial do intervalo intrajornada mínimo implica o pagamento total do período correspondente, com acréscimo de, no mínimo, 50% sobre o valor da remuneração da hora normal.",area:"Direito do Trabalho",tags:["intervalo","jornada","hora extra"]},
];

const TRIBUNAIS=[{v:"Todos",l:"Todos"},{v:"STF",l:"STF"},{v:"STJ",l:"STJ"},{v:"TST",l:"TST"},{v:"TSE",l:"TSE"},{v:"TRF1",l:"TRF-1"},{v:"TRF2",l:"TRF-2"},{v:"TRF3",l:"TRF-3"},{v:"TRF4",l:"TRF-4"},{v:"TRF5",l:"TRF-5"},{v:"TJSP",l:"TJSP"}];
const PERIODOS=["Qualquer período","2023–2025","2020–2022","2017–2019","2015–2016","Antes de 2015"];
const AREAS_B=["Todas as áreas","Processo Civil","Processo Penal","Direito Civil","Direito Penal","Direito Tributário","Direito Administrativo","Direito Constitucional","Direito do Trabalho","Direito Empresarial","Direito do Consumidor","Direito Bancário","Mercado de Capitais"];

function citacaoInline(r){if(r.tipo?.includes("Súmula"))return`o ${r.tribunal}, na ${r.tipo} n. ${r.numero}, consolidou o entendimento de que "${r.ementa.slice(0,120)}..."`;return`o ${r.tribunal}, ao julgar o ${r.tipo||"acórdão"} ${r.numero||"n. XXXXX"}/${r.uf||"UF"}, assentou que "${(r.ementa||"").slice(0,120)}..."`;}
function notaRodape(r){if(r.tipo?.includes("Súmula"))return`N ${r.tribunal}, ${r.tipo} n. ${r.numero}: "${r.ementa.slice(0,120)}..."`;return`N ${r.tribunal}, ${r.tipo||"Acórdão"} ${r.numero||"XXXXX"}/${r.uf||"UF"}.`;}

function SumulaCard({r}){
  const[cp,setCp]=useState(null);const[saved,setSaved]=useState(null);
  const C={border:"#ddd9d0",bg:"#faf8f4",nav:"#12192e",textSec:"#555",textTer:"#999"};
  const corTrib={STF:"#7c3aed",STJ:"#0369a1",TST:"#065f46",TSE:"#92400e"}[r.tribunal]||"#555";
  const copiar=async(texto,key)=>{navigator.clipboard?.writeText(texto);await jurCacheAddLocal(texto);setCp(key);setSaved(key);setTimeout(()=>{setCp(null);setSaved(null);},2500);};
  return(
    <div style={{background:"white",border:`1px solid ${C.border}`,borderLeft:`3px solid ${corTrib}`,borderRadius:6,padding:"14px 16px",marginBottom:10}}>
      <div style={{display:"flex",gap:8,marginBottom:8,flexWrap:"wrap",alignItems:"center"}}>
        <span style={{background:`${corTrib}18`,color:corTrib,border:`1px solid ${corTrib}40`,fontSize:11,padding:"2px 10px",borderRadius:10,fontFamily:"monospace",fontWeight:700}}>{r.tribunal}</span>
        <span style={{background:"#ede8df",color:C.textSec,fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace"}}>{r.tipo} n. {r.numero}</span>
        <span style={{background:"#ede8df",color:C.textSec,fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace"}}>{r.area}</span>
        {saved&&<span style={{background:"#f0fdf4",color:"#166534",border:"1px solid #86efac",fontSize:10,padding:"2px 8px",borderRadius:10,fontFamily:"monospace",marginLeft:"auto"}}>✅ salvo no Hub</span>}
      </div>
      <div style={{fontSize:13,fontWeight:700,color:C.nav,marginBottom:6}}>{r.tema}</div>
      <div style={{fontSize:12,color:C.textSec,lineHeight:1.7,marginBottom:10,fontStyle:"italic",borderLeft:"2px solid #e5e0d8",paddingLeft:12}}>{r.ementa}</div>
      <div style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:4,padding:"8px 12px",fontSize:11,lineHeight:1.7,color:"#333",marginBottom:10}}>
        <span style={{fontSize:9,fontFamily:"monospace",color:C.textTer,display:"block",marginBottom:2,textTransform:"uppercase"}}>Citação inline</span>
        {citacaoInline(r)}
      </div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
        <button onClick={()=>copiar(citacaoInline(r),"inline")} style={{padding:"5px 13px",background:cp==="inline"?"#f0fdf4":"transparent",border:`1px solid ${cp==="inline"?"#86efac":"#ddd9d0"}`,borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:cp==="inline"?"#166534":"#555"}}>{cp==="inline"?"✅ copiado + salvo!":"📋 Copiar inline"}</button>
        <button onClick={()=>copiar(notaRodape(r),"fn")} style={{padding:"5px 13px",background:cp==="fn"?"#f0fdf4":"transparent",border:`1px solid ${cp==="fn"?"#86efac":"#ddd9d0"}`,borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:cp==="fn"?"#166534":"#555"}}>{cp==="fn"?"✅ copiado + salvo!":"ⁿ Copiar nota"}</button>
        {r.tags&&<div style={{display:"flex",gap:4,flexWrap:"wrap",marginLeft:"auto"}}>{r.tags.map(t=><span key={t} style={{fontSize:9,padding:"2px 7px",background:"#ede8df",borderRadius:10,color:"#999",fontFamily:"monospace"}}>{t}</span>)}</div>}
      </div>
    </div>
  );
}

export default function JurJurisprudencia(){
  const[tema,setTema]=useState("");const[tribunal,setTribunal]=useState("Todos");const[periodo,setPeriodo]=useState("Qualquer período");const[area,setArea]=useState("Todas as áreas");const[modo,setModo]=useState("sumulas");const[loading,setLoading]=useState(false);const[iaResult,setIaResult]=useState("");const[iaErro,setIaErro]=useState("");const[historico,setHistorico]=useState([]);

  const resultados=SUMULAS.filter(r=>{const q=tema.toLowerCase();const mT=!tema||[r.tema,r.ementa,r.numero,...(r.tags||[])].some(s=>s.toLowerCase().includes(q));const mTr=tribunal==="Todos"||r.tribunal===tribunal;const mA=area==="Todas as áreas"||r.area.includes(area.split(" ")[0]);return mT&&mTr&&mA;});

  const buscarIA=useCallback(async()=>{
    if(!tema.trim())return;
    setLoading(true);setIaResult("");setIaErro("");
    try{
      const resp=await fetch("/api/claude",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:`Pesquise jurisprudência REAL e VERIFICADA sobre:\nTema: "${tema}"\nTribunal(is): ${tribunal==="Todos"?"STF, STJ, TST e TRFs":tribunal} | Período: ${periodo==="Qualquer período"?"2018–2025":periodo}${area!=="Todas as áreas"?`\nÁrea: ${area}`:""}\n\nREGRAS: ✗ NUNCA invente número, relator, data ou ementa\n✓ Somente julgados com alta confiança\n\nPara cada julgado:\n---\n**[TRIBUNAL] — [Tipo] [número]/[UF]**\nRelator: [Min. Nome] | Data: [DD/MM/AAAA]\nTese fixada: [enunciado]\n📋 CITAÇÃO INLINE: "o [Tribunal], ao julgar o [tipo] [número]/[UF], [Rel. Min. Nome], j. [data], fixou a tese de que [tese]"\nⁿ NOTA DE RODAPÉ: "N [Tribunal], [tipo] [número]/[UF], Rel. Min. Nome, j. data."\n---\n**TENDÊNCIA DO TRIBUNAL:** [2–3 frases]\nListe pelo menos 5 julgados:`}],tools:[{type:"web_search_20250305",name:"web_search"}]})});
      const data=await resp.json();const txt=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim();
      if(!txt)throw new Error("Resposta vazia.");setIaResult(txt);
      setHistorico(prev=>[{tema,tribunal,periodo,txt,ts:new Date().toLocaleTimeString("pt-BR")},...prev.slice(0,4)]);
    }catch(e){setIaErro("❌ Erro: "+(e.message||"verifique a conexão."));}
    setLoading(false);
  },[tema,tribunal,periodo,area]);

  const C={bg:"#f5f4f1",white:"white",nav:"#12192e",gold:"#c49a2a",border:"#ddd9d0",textPri:"#111",textSec:"#555",textTer:"#999"};

  return(
    <div style={{height:"100%",display:"flex",flexDirection:"column",background:C.bg,overflow:"hidden"}}>
      <div style={{background:C.nav,padding:"0 22px",display:"flex",alignItems:"center",gap:12,height:48,flexShrink:0,borderBottom:"1px solid #0a1020"}}>
        <span style={{color:C.gold,fontFamily:"monospace",fontWeight:700,fontSize:13,letterSpacing:".1em"}}>JURJURISPRUDÊNCIA</span>
        <span style={{background:`${C.gold}25`,border:`1px solid ${C.gold}55`,color:C.gold,fontSize:9,padding:"2px 8px",borderRadius:2,fontFamily:"monospace"}}>v2 · auto-save Hub</span>
        <span style={{fontSize:11,color:"rgba(255,255,255,.4)",fontFamily:"monospace"}}>Copiar → grava automaticamente no Hub</span>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"18px 20px",maxWidth:920,margin:"0 auto",width:"100%",boxSizing:"border-box"}}>
        <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:8,padding:"14px 18px",marginBottom:14}}>
          <div style={{display:"flex",gap:10,marginBottom:10}}>
            <input value={tema} onChange={e=>setTema(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")buscarIA();}} placeholder="Pesquisar... Ex: usucapião, bis in idem, demissão por justa causa" style={{flex:1,padding:"9px 12px",border:`1px solid ${C.border}`,borderRadius:6,fontFamily:"Georgia,serif",fontSize:13,background:C.bg,outline:"none"}}/>
            <button onClick={buscarIA} disabled={loading||!tema.trim()} style={{padding:"9px 20px",background:loading?"#aaa":C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:13,fontFamily:"monospace",fontWeight:700,whiteSpace:"nowrap"}}>{loading?"⏳...":"🔍 Buscar IA"}</button>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
            {[["Tribunal",tribunal,setTribunal,TRIBUNAIS.map(t=>({v:t.v,l:t.l}))],["Período",periodo,setPeriodo,PERIODOS.map(p=>({v:p,l:p}))],["Área",area,setArea,AREAS_B.map(a=>({v:a,l:a}))]].map(([label,val,setter,opts])=>(
              <div key={label}><div style={{fontSize:9,fontFamily:"monospace",color:C.textTer,textTransform:"uppercase",letterSpacing:".07em",marginBottom:4}}>{label}</div><select value={val} onChange={e=>setter(e.target.value)} style={{width:"100%",padding:"6px 8px",border:`1px solid ${C.border}`,borderRadius:4,fontFamily:"Georgia,serif",fontSize:12,background:C.bg,outline:"none"}}>{opts.map(o=><option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}</select></div>
            ))}
          </div>
        </div>
        <div style={{display:"flex",gap:0,marginBottom:14,borderBottom:`1px solid ${C.border}`}}>
          {[["sumulas",`⚖️ Súmulas (${SUMULAS.length})`],["ia","🔍 Busca IA + Web"],["historico",`🕑 Histórico (${historico.length})`]].map(([id,label])=>(
            <button key={id} onClick={()=>setModo(id)} style={{padding:"9px 18px",fontSize:12,fontFamily:"monospace",border:"none",background:modo===id?C.white:"transparent",cursor:"pointer",color:modo===id?C.nav:C.textTer,fontWeight:modo===id?700:400,borderBottom:modo===id?`2px solid ${C.gold}`:"2px solid transparent",marginBottom:-1}}>{label}</button>
          ))}
        </div>
        {modo==="sumulas"&&(
          <>
            <div style={{marginBottom:10,fontSize:11,fontFamily:"monospace",color:C.textTer}}>{resultados.length} resultado{resultados.length!==1?"s":""} — copiar salva automaticamente no Hub</div>
            {resultados.length===0?<div style={{textAlign:"center",padding:"40px 0",color:C.textTer}}><div style={{fontSize:32,marginBottom:10}}>⚖️</div><div>Nenhuma súmula encontrada — use Busca IA</div><button onClick={()=>setModo("ia")} style={{marginTop:12,padding:"8px 20px",background:C.nav,color:"white",border:"none",borderRadius:6,cursor:"pointer",fontSize:12,fontFamily:"monospace"}}>🔍 Ir para Busca IA</button></div>:resultados.map(r=><SumulaCard key={r.id} r={r}/>)}
          </>
        )}
        {modo==="ia"&&(
          <>
            {iaErro&&<div style={{padding:"10px 14px",background:"#fef2f2",border:"1px solid #fca5a5",borderRadius:4,fontSize:12,color:"#991b1b",fontFamily:"monospace",marginBottom:12}}>{iaErro}</div>}
            {!iaResult&&!loading&&!iaErro&&(
              <div style={{textAlign:"center",padding:"48px 0",color:C.textTer}}>
                <div style={{fontSize:36,marginBottom:14}}>⚖️</div>
                <div style={{fontSize:13,color:C.textSec,marginBottom:14}}>Digite o tema e clique em Buscar IA — resultados salvos no Hub ao copiar</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,maxWidth:560,margin:"0 auto",textAlign:"left"}}>
                  {["responsabilidade civil do Estado","usucapião extrajudicial","bis in idem tributário","demissão por justa causa","prazo prescricional consumidor","impenhorabilidade bem de família"].map(s=><button key={s} onClick={()=>setTema(s)} style={{padding:"8px 10px",border:`1px solid ${C.border}`,borderRadius:4,cursor:"pointer",background:C.white,textAlign:"left",fontSize:11,color:C.textSec,fontFamily:"Georgia,serif",lineHeight:1.4}}>{s}</button>)}
                </div>
              </div>
            )}
            {loading&&<div style={{textAlign:"center",padding:"48px 0"}}><div style={{fontSize:13,color:C.textSec,fontFamily:"monospace",marginBottom:16}}>⏳ Pesquisando jurisprudência + web...</div></div>}
            {iaResult&&(
              <div style={{background:"white",border:"1px solid #ddd9d0",borderLeft:"3px solid #16a34a",borderRadius:6,padding:"16px",marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,gap:8,flexWrap:"wrap"}}>
                  <span style={{fontSize:10,fontFamily:"monospace",color:"#166534",fontWeight:700}}>🔍 Jurisprudência IA + Web</span>
                  <div style={{display:"flex",gap:6}}>
                    <button onClick={()=>{jurCacheAddLocal(iaResult);}} style={{padding:"4px 12px",background:"transparent",border:"1px solid #ddd9d0",borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:"#555"}}>💾 Salvar no Hub</button>
                    <button onClick={()=>{navigator.clipboard?.writeText(iaResult);jurCacheAddLocal(iaResult);}} style={{padding:"4px 12px",background:"transparent",border:"1px solid #ddd9d0",borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:"#555"}}>📋 Copiar tudo</button>
                  </div>
                </div>
                <div style={{fontSize:12,lineHeight:1.9,color:"#1a1a1a",fontFamily:"Georgia,serif",whiteSpace:"pre-wrap"}}>{iaResult}</div>
              </div>
            )}
          </>
        )}
        {modo==="historico"&&(
          historico.length===0?<div style={{textAlign:"center",padding:"40px 0",color:C.textTer}}><div style={{fontSize:32,marginBottom:10}}>🕑</div><div>Nenhuma busca ainda nesta sessão</div></div>:
          historico.map((h,i)=>(
            <div key={i} style={{background:"white",border:"1px solid #ddd9d0",borderRadius:6,padding:"12px 16px",marginBottom:10}}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}><span style={{fontSize:12,fontWeight:700,color:"#111"}}>{h.tema}</span><span style={{fontSize:10,fontFamily:"monospace",color:"#999"}}>{h.tribunal} · {h.ts}</span></div>
              <div style={{fontSize:11,color:"#555",lineHeight:1.6,maxHeight:70,overflow:"hidden",borderTop:"1px solid #ddd9d0",paddingTop:6}}>{h.txt.slice(0,400)}...</div>
              <button onClick={()=>{setIaResult(h.txt);setTema(h.tema);setModo("ia");}} style={{marginTop:6,padding:"4px 12px",background:"transparent",border:"1px solid #ddd9d0",borderRadius:4,cursor:"pointer",fontSize:11,fontFamily:"monospace",color:"#555"}}>Ver resultado →</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
