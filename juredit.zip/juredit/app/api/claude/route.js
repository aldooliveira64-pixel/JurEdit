// ═══════════════════════════════════════════════════════════════════
// API ROUTE — Proxy seguro para a API Anthropic
// A chave ANTHROPIC_API_KEY fica no servidor (Vercel env vars)
// Nunca é exposta no browser
// ═══════════════════════════════════════════════════════════════════
export async function POST(request) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return Response.json({ error: "ANTHROPIC_API_KEY não configurada no servidor." }, { status: 500 });
  }

  try {
    const body = await request.json();

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "web-search-2025-03-05",
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (!response.ok) {
      return Response.json({ error: data?.error?.message || "Erro na API Anthropic" }, { status: response.status });
    }

    return Response.json(data);
  } catch (err) {
    return Response.json({ error: err.message || "Erro interno" }, { status: 500 });
  }
}
