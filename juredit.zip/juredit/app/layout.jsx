import "./globals.css";
export const metadata = { title: "JurEdit — Ecossistema Jurídico", description: "Plataforma jurídica inteligente" };
export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
